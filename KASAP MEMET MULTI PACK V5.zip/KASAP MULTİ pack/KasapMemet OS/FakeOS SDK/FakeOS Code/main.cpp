/*
KASAP MEMET SOFTWARE inc. Present 1996-2026 FakeOS SDK Win32API Using !

If You used SDK And made a new FakeOS project You must type This but change "Project ID" but do not change "Orginal Project ID"
And if using FakeOS SDK and made Project then you must Project made General Public License-3.0 And Open-Source project.

GPL 3.0 Licensed OS Engine
Project ID : 12148
Orginal Project ID : 12148
ISO/IEC 14882:1998 (ISO C++98); Before 1998 ISO/IEC 9899:1990 (ISO C89)
*/
#include <windows.h>
#include <mmsystem.h>

// Global window handle declarations for various OS components and dialogs
HWND hwnd1 = NULL;
HWND hBtn1 = NULL;
HWND Start = NULL;
HWND hBtn2 = NULL;
HWND hEditBox1 = NULL;
HWND hBtnN = NULL;
HWND hEditBox2 = NULL;
HWND scanner = NULL;
HWND hBtnE = NULL;
HWND hBtnE1 = NULL;
HWND hEditBox3 = NULL;
HWND hEditBox4 = NULL;
HWND hBtnE2 = NULL;
HWND hBtnE3 = NULL;
HWND hBtnE4 = NULL;
HWND hBtnE5 = NULL;
HWND hBtn44 = NULL;
HWND hBtn45 = NULL;
HWND hBtnExe = NULL;
HWND Del = NULL;
HWND hText999Del = NULL;
HWND hDelT2 = NULL;
HWND hBtnExe2 = NULL;
HWND hBtnExe1 = NULL;

bool bypass = false; // Security flag to bypass standard window constraints

LRESULT CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam) {
    switch(Message) {
        
        case WM_DESTROY: {
            PostQuitMessage(0); // Exit main application loop
            break;
        }
        case WM_CLOSE: {
            // Handle custom close behavior depending on which window triggered the message
            if (hwnd == hwnd1) {
                ShowWindow(hwnd1, SW_HIDE);
                return 0;
            }
            else if (hwnd == Start) {
                ShowWindow(Start, SW_HIDE);
                return 0;
            }
            else if (hwnd == scanner) {
                ShowWindow(scanner, SW_HIDE);
                return 0;
            }
            else if (hwnd == Del){
                MessageBox(Del, "Please Choose !", "!", MB_OK | MB_ICONEXCLAMATION);
                return 0;
            }
            else if (hwnd == hwnd) {
                return 0; 
            }
            DestroyWindow(hwnd);
            break;
        }
        case WM_COMMAND: {
            
            // Handle button clicks and menu commands with sound effects and UI toggles
            if (LOWORD(wParam) == 1){
                PlaySound("Tech.wav", NULL, SND_FILENAME | SND_ASYNC);
                //Your Choose
            }
            else if (LOWORD(wParam) == 2){
                //Your Choose
            }
            else if (LOWORD(wParam) == 3){
                //Your Choose
            }
            else if (LOWORD(wParam) == 14){
                //Your Choose
            }
            else if (LOWORD(wParam) == 15){
                //Your Choose
            }
            else if (LOWORD(wParam) == 16){
                //Your Choose
            }
            else if (LOWORD(wParam) == 44){
                //Your Choose
            }
            else if (LOWORD(wParam) == 45){
                //Your Choose
            }
            else if (LOWORD(wParam) == 99){
                //Your Choose
            }
            else if (LOWORD(wParam) == 434){
                //Your Choose
            }
            
            break;
        }
        case WM_KEYDOWN: {
            // Global keyboard shortcuts for system control
            if (wParam == VK_SHIFT) {
                if (!bypass){
                //Your Choose
                }
                return 0;
            }
            else if (wParam == VK_F12) {
                if (!bypass){
                //Your Choose
            }
            return 0;
            }
            else if (wParam == VK_F11) {
                if (!bypass){
                //Your Choose
            }
            return 0;
            }
            break;
        }
        
        default:
            return DefWindowProc(hwnd, Message, wParam, lParam);
    }
    return 0;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    
    ShowWindow(hwnd1, SW_HIDE); //hide hwnd1
    PlaySound("ADS.wav", NULL, SND_FILENAME | SND_ASYNC); //Play Starting Sound
     
    HWND hwnd;

    WNDCLASSEX wc1; 
    WNDCLASSEX wc2; 
    MSG msg; 

    // Register standard window class with grey background
    ZeroMemory(&wc1, sizeof(WNDCLASSEX));
    wc1.cbSize           = sizeof(WNDCLASSEX);
    wc1.lpfnWndProc      = WndProc; 
    wc1.hInstance        = hInstance;
    wc1.hCursor          = LoadCursor(NULL, IDC_ARROW);
    wc1.hbrBackground    = CreateSolidBrush(RGB(150, 150, 150));
    wc1.lpszClassName    = "WindowClass";
    wc1.hIcon            = LoadIcon(NULL, IDI_APPLICATION); 
    wc1.hIconSm          = LoadIcon(NULL, IDI_APPLICATION); 
    
    // Register warning window class with red background
    ZeroMemory(&wc2, sizeof(WNDCLASSEX));
    wc2.cbSize           = sizeof(WNDCLASSEX);
    wc2.lpfnWndProc      = WndProc; 
    wc2.hInstance        = hInstance;
    wc2.hCursor          = LoadCursor(NULL, IDC_ARROW);
    wc2.hbrBackground    = CreateSolidBrush(RGB(255, 0, 0));
    wc2.lpszClassName    = "Deltopc";
    wc2.hIcon            = LoadIcon(NULL, IDI_EXCLAMATION); 
    wc2.hIconSm          = LoadIcon(NULL, IDI_EXCLAMATION);

    if(!RegisterClassEx(&wc1)) {
        MessageBox(NULL, "Window Registration Failed!","Error!",MB_ICONEXCLAMATION|MB_OK);
        return 0;
    }
    if(!RegisterClassEx(&wc2)) {
        MessageBox(NULL, "Window Registration Failed!","Error!",MB_ICONEXCLAMATION|MB_OK);
        return 0;
    }
    
    int Sx = GetSystemMetrics(SM_CXSCREEN);
    int Sy = GetSystemMetrics(SM_CYSCREEN);
    
    // Create Start Menu window positioned near the bottom left
    hwnd1 = CreateWindowEx(WS_EX_CLIENTEDGE,"WindowClass","Start Menu",WS_POPUP,
        0, 
        Sy - 550, 
        300, 
        500, 
        NULL,NULL,hInstance,NULL);

    // Create main fullscreen desktop background window
    hwnd = CreateWindowEx(WS_EX_CLIENTEDGE,"WindowClass","FakeOS",WS_VISIBLE|WS_POPUP,
        0, 
        0, 
        Sx, 
        Sy, 
        NULL,NULL,hInstance,NULL);
        
    // Create warning popup dialog window
    Del = CreateWindowEx(WS_EX_CLIENTEDGE,"Deltopc","Warning",WS_SYSMENU,
        0, 
        0, 
        640, 
        480, 
        NULL,NULL,hInstance,NULL);
        
    // Create file explorer window component
    scanner = CreateWindowEx(WS_EX_CLIENTEDGE,"WindowClass","File Explorer",WS_SYSMENU,
        100, 
        100, 
        640, 
        480, 
        NULL,NULL,hInstance,NULL);
        
    // Create Notepad app window
    Start = CreateWindowEx(WS_EX_CLIENTEDGE,"WindowClass","Kasap Not Defteri Version 1.0",WS_OVERLAPPEDWINDOW,
        0, 
        0, 
        640, 
        480, 
        NULL,NULL,hInstance,NULL);
        
    // Standard font definition (Size 24)
    HFONT hFont1 = CreateFontA(
    24,                       
    0,                        
    0,                        
    0,                        
    FW_BOLD,                  
    FALSE,                    
    FALSE,                    
    FALSE,                    
    DEFAULT_CHARSET,          
    OUT_DEFAULT_PRECIS,       
    CLIP_DEFAULT_PRECIS,      
    DEFAULT_QUALITY,          
    DEFAULT_PITCH | FF_DONTCARE, 
    "Comic Sans MS"             
);

    // Medium font definition (Size 36)
    HFONT hFont2 = CreateFontA(
    36,                       
    0,                        
    0,                        
    0,                        
    FW_BOLD,                  
    FALSE,                    
    FALSE,                    
    FALSE,                    
    DEFAULT_CHARSET,          
    OUT_DEFAULT_PRECIS,       
    CLIP_DEFAULT_PRECIS,      
    DEFAULT_QUALITY,          
    DEFAULT_PITCH | FF_DONTCARE, 
    "Comic Sans MS"             
);

    // Large font definition (Size 120)
    HFONT hFont3 = CreateFontA(
    120,                      
    0,                        
    0,                        
    0,                        
    FW_BOLD,                  
    FALSE,                    
    FALSE,                    
    FALSE,                    
    DEFAULT_CHARSET,          
    OUT_DEFAULT_PRECIS,       
    CLIP_DEFAULT_PRECIS,      
    DEFAULT_QUALITY,          
    DEFAULT_PITCH | FF_DONTCARE, 
    "Comic Sans MS"             
);

// Static text controls for desktop info and dialog UI elements
HWND hText1 = CreateWindowEx(
    0, 
    "STATIC",                            
    "",          
    WS_CHILD | WS_VISIBLE, 
    0, Sy - 60,                         
    2000, 300,                         
    hwnd,                                 
    NULL, hInstance, NULL
);

HWND hText999 = CreateWindowEx(
    0, 
    "STATIC",                            
    "Creator is KASAPMEMET Im Stupid Version 3.2",          
    WS_CHILD | WS_VISIBLE, 
    200, Sy - 40,                         
    500, 100,                         
    hwnd,                                 
    NULL, hInstance, NULL
);

HWND hText999Del = CreateWindowEx(
    0, 
    "STATIC",                            
    "Do you want Trash your computer ?",          
    WS_CHILD | WS_VISIBLE, 
    100, 100,                         
    300, 100,                         
    Del,                                 
    NULL, hInstance, NULL
);
HWND hDelT3 = CreateWindowEx(
    0, 
    "STATIC",                            
    "!",          
    WS_CHILD | WS_VISIBLE | SS_CENTER, 
    450, 100,                         
    100, 100,                         
    Del,                                 
    NULL, hInstance, NULL
);

HWND hDelT2 = CreateWindowEx(
    0, 
    "STATIC",                            
    "OR",          
    WS_CHILD | WS_VISIBLE | SS_CENTER, 
    230, 300,                         
    100, 50,                         
    Del,                                 
    NULL, hInstance, NULL
);

// Edit controls for file explorer path and search input
hEditBox3 = CreateWindowEx(
        WS_EX_CLIENTEDGE, 
        "EDIT", 
        "Computer\\", 
        WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL,
        10, 10, 400, 25, 
        scanner, NULL, hInstance, NULL
    );
    
    hEditBox4 = CreateWindowEx(
        WS_EX_CLIENTEDGE, 
        "EDIT", 
        "Search for Computer\\",
        WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL,
        420, 10, 200, 25, 
        scanner, NULL, hInstance, NULL
    );

// Desktop shortcut buttons
hBtnN = CreateWindowEx(
    0,
    "BUTTON",                         
    "Kasap Not Defteri",                         
    WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 
    10, 10,                         
    150, 100,                        
    hwnd,                            
    (HMENU)3,                        
    hInstance, NULL
);

hBtnE = CreateWindowEx(
    0,
    "BUTTON",                         
    "File Explorer",                         
    WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 
    10, 150,                         
    150, 100,                        
    hwnd,                            
    (HMENU)14,                       
    hInstance, NULL
);

hBtnExe = CreateWindowEx(
    0,
    "BUTTON",                         
    "Fir�s",                         
    WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 
    10, 290,                         
    150, 100,                        
    hwnd,                            
    (HMENU)99,                       
    hInstance, NULL
);

hBtnExe1 = CreateWindowEx(
    0,
    "BUTTON",                         
    "Yes",                         
    WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 
    50, 300,                         
    150, 50,                        
    Del,                             
    (HMENU)434,                      
    hInstance, NULL
);

hBtnExe2 = CreateWindowEx(
    0,
    "BUTTON",                         
    "Yes",                         
    WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 
    360, 300,                        
    150, 50,                        
    Del,                             
    (HMENU)434,                      
    hInstance, NULL
);

// File explorer directory and file navigation buttons
hBtnE1 = CreateWindowEx(
    0,
    "BUTTON",                         
    "C:\\ (Disk)",                         
    WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 
    10, 50,                         
    110, 110,                        
    scanner,                         
    (HMENU)15,                       
    hInstance, NULL
);

hBtnE2 = CreateWindowEx(
    0,
    "BUTTON",                         
    "System (FOLDER)",                         
    WS_CHILD | BS_PUSHBUTTON, 
    10, 50,                         
    200, 100,                        
    scanner,                         
    (HMENU)13,                       
    hInstance, NULL
);
hBtnE3 = CreateWindowEx(
    0,
    "BUTTON",                         
    "Users (FOLDER)",                         
    WS_CHILD | BS_PUSHBUTTON, 
    10, 150,                         
    200, 100,                        
    scanner,                         
    (HMENU)13,                       
    hInstance, NULL
);
hBtnE4 = CreateWindowEx(
    0,
    "BUTTON",                         
    "Kernel.dll (FILE)",                         
    WS_CHILD | BS_PUSHBUTTON, 
    10, 250,                         
    200, 100,                        
    scanner,         
    (HMENU)13,                       
    hInstance, NULL
);

hBtnE5 = CreateWindowEx(
    0,
    "BUTTON",                         
    "Unknown (Disk)",                         
    WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 
    200, 50,                         
    110, 110,                        
    scanner,         
    (HMENU)16,                       
    hInstance, NULL
);

// Taskbar and Start Menu system buttons
hBtn1 = CreateWindowEx(
    0,
    "BUTTON",                         
    "Start",                         
    WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 
    10, Sy - 55,                     
    150, 50,                         
    hwnd,                            
    (HMENU)1,                        
    hInstance, NULL
);

hBtn2 = CreateWindowEx(
    0,
    "BUTTON",                         
    "Power Off",                         
    WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 
    500 - 360, 420,                         
    150, 50,                         
    hwnd1,                           
    (HMENU)2,                        
    hInstance, NULL
);

hBtn44 = CreateWindowEx(
    0,
    "BUTTON",                         
    "docx Technology Overview",                         
    WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 
    50, 100,                         
    200, 50,                         
    hwnd1,                           
    (HMENU)44,                       
    hInstance, NULL
);
hBtn45 = CreateWindowEx(
    0,
    "BUTTON",                         
    "pdf Technology Overview",                         
    WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 
    50, 10,                          
    200, 50,                         
    hwnd1,                           
    (HMENU)45,                       
    hInstance, NULL
);

// Notepad text editor edit controls
hEditBox1 = CreateWindowEx(
    WS_EX_CLIENTEDGE, 
    "EDIT",
    "Creator is Kasap Memet\r\n\r\nControls\r\n\r\nShift = Start Menu\r\nF12 = Close Everything on FakeOS\r\nF11 = Open Everything on FakeOS\r\n", 
    WS_CHILD | WS_VISIBLE | ES_MULTILINE | ES_AUTOVSCROLL | ES_AUTOHSCROLL,
    0, 50, Sx, Sy, 
    Start, NULL, hInstance, NULL
);
hEditBox2 = CreateWindowEx(
    WS_EX_CLIENTEDGE, 
    "EDIT", 
    "=== KASAP MEMET NOTEPAD ===", 
    WS_CHILD | WS_VISIBLE | ES_MULTILINE | ES_AUTOVSCROLL | ES_AUTOHSCROLL,
    0, 0, Sx, 50, 
    Start, NULL, hInstance, NULL
);

// Apply custom font handles to respective windows and text elements
SendMessage(hEditBox1, WM_SETFONT, (WPARAM)hFont1, (LPARAM)TRUE);
SendMessage(hEditBox2, WM_SETFONT, (WPARAM)hFont2, (LPARAM)TRUE);
SendMessage(hText999Del, WM_SETFONT, (WPARAM)hFont2, (LPARAM)TRUE);
SendMessage(hDelT2, WM_SETFONT, (WPARAM)hFont2, (LPARAM)TRUE);
SendMessage(hDelT3, WM_SETFONT, (WPARAM)hFont3, (LPARAM)TRUE);

    if(hwnd == NULL) {
        MessageBox(NULL, "Window Creation Failed!","Error!",MB_ICONEXCLAMATION|MB_OK);
        return 0;
    }

    while(GetMessage(&msg, NULL, 0, 0) > 0) { 
        TranslateMessage(&msg); 
        DispatchMessage(&msg); 
    }
    return msg.wParam;
}
