/*
KASAP MEMET SOFTWARE inc. Present 1996-2026 FakeOS SDK Win32API Using !

If You used SDK And made a new FakeOS project You must type This but change "Project ID" but do not change "Orginal Project ID"
And if using FakeOS SDK and made Project then you must Project made General Public License-3.0 And Open-Source project.

GPL 3.0 Licensed OS Engine
Project ID : 12148
Orginal Project ID : 12148
ISO/IEC 14882:1998 (ISO C++98); Before 1998 ISO/IEC 9899:1990 (ISO C89)
*/

#include <windows.h>
#include <cstdlib>

HWND hText1 = NULL;

LRESULT CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam) {
    switch(Message) {
        
        case WM_DESTROY: {
            PostQuitMessage(0);
            break;
        }
        case WM_CLOSE: {
        	
        }
        case WM_KEYDOWN: {
            if (wParam == VK_F12) {
            	system("taskkill /f /im tool.exe");
            	system("taskkill /f /im beep.exe");
            	ShellExecute(NULL, "open", "C:\\Windows\\explorer.exe", NULL, NULL, SW_SHOW);
                PostQuitMessage(0);
            }
            break;
        }
        case WM_CTLCOLORSTATIC: { //Change Static Text Backrounds
            HDC hdcStatic = (HDC)wParam;
            HWND hwndStatic = (HWND)lParam;
            if (hText1 == hText1) {
                SetTextColor(hdcStatic, RGB(255, 255, 255)); //white text
                SetBkColor(hdcStatic, RGB(0, 0, 128)); //Navy Blue (bsod color);
                static HBRUSH hBlueBrush = CreateSolidBrush(RGB(0, 0, 128));
                return (INT_PTR)hBlueBrush;
            }
            break;
        }
        
        default:
            return DefWindowProc(hwnd, Message, wParam, lParam);
    }
    return 0;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
	
	ShellExecute(NULL, "open", "tool.exe", NULL, NULL, SW_SHOW); //Open tool.exe
	ShellExecute(NULL, "open", "beep.exe", NULL, NULL, SW_SHOW); //Open beep.exe
	system("taskkill /f /im explorer.exe"); //Close Force All Explorers
    
    WNDCLASSEX wc; //Definition for wc
    HWND hwnd; //Save Main Window
    MSG msg; 

    memset(&wc,0,sizeof(wc));
    wc.cbSize          = sizeof(WNDCLASSEX);
    wc.lpfnWndProc     = WndProc; 
    wc.hInstance     = hInstance;
    wc.hCursor         = LoadCursor(NULL, IDC_ARROW); //Mouse Cursor Select Here Example IDC_ARROW
    
    wc.hbrBackground = CreateSolidBrush(RGB(0, 0, 128)); //Backround color Currently Navy blue (bsod color);
    wc.lpszClassName = "WindowClass"; //Definition Class Name
    wc.hIcon         = LoadIcon(NULL, IDI_APPLICATION); //Window Icon example IDI_WARNING
    wc.hIconSm         = LoadIcon(NULL, IDI_APPLICATION); //Big Window Icon example IDI_WARNING

    if(!RegisterClassEx(&wc)) {
        MessageBox(NULL, "Window Registration Failed!","Error!",MB_ICONEXCLAMATION|MB_OK);
        return 0;
    }
    
    int Sx = GetSystemMetrics(SM_CXSCREEN); //Get X Axis Resolution
    int Sy = GetSystemMetrics(SM_CYSCREEN); //Get Y Axis Resolution
    hwnd = CreateWindowEx(WS_EX_CLIENTEDGE,"WindowClass","FakeOS",WS_VISIBLE|WS_POPUP, //Create Main Window Here //WS_VISIBLE is Start Visible WS_POPUP is No Borderless Window
        0, //Start X Position 
        0, //Start Y Position
        Sx, //Screen X Axis Resolution
        Sy, //Screen Y Axis Resolution
        NULL,NULL,hInstance,NULL);

        
    HFONT hFont1 = CreateFontA( //Create Font - ANSI
    36, //Font Scale                      
    0, //widht                       
    0, //Escapement angle        
    0, //Orientation angle          
    FW_BOLD, //Font weight
    FALSE,   //Italic                
    FALSE,   //Underline                
    FALSE,   //StrikeOut                
    DEFAULT_CHARSET, //Chacter Set        
    OUT_DEFAULT_PRECIS, //Output Precision   
    CLIP_DEFAULT_PRECIS, //Clipping Precision    
    DEFAULT_QUALITY, //Output Quality        
    DEFAULT_PITCH | FF_DONTCARE, //Pitch And Family
    "Comic Sans MS" //Font name             
);

HWND hText1 = CreateWindowEx(
    0, 
    "STATIC",                           
    "Your Text\r\n\r\n"
    "Your Text\r\n\r\n"
    "Your Text\r\n\r\n"
    "Your Text",          
    WS_CHILD | WS_VISIBLE, 
    10, 10,                         
    2000, 300,                         
    hwnd,                               
    NULL, hInstance, NULL
);

SendMessage(hText1, WM_SETFONT, (WPARAM)hFont1, (LPARAM)TRUE); //Set Font on hText1

    if(hwnd == NULL) { //Check Registered Window
        MessageBox(NULL, "Window Creation Failed!","Error!",MB_ICONEXCLAMATION|MB_OK); //if didnt registered Window Show This Error Message
        return 0;
    }

    while(GetMessage(&msg, NULL, 0, 0) > 0) { //Peek Message Loop for Window Life
        TranslateMessage(&msg); 
        DispatchMessage(&msg); 
    }
    return msg.wParam;
}
