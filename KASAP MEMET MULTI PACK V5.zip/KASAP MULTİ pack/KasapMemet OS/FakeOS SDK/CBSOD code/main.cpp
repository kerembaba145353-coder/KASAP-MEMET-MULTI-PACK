/*
KASAP MEMET SOFTWARE inc. Present 1996-2026 FakeOS SDK Win32API Using !

If You used SDK And made a new FakeOS project You must type This but change "Project ID" but do not change "Orginal Project ID"
And if using FakeOS SDK and made Project then you must Project made General Public License-3.0 And Open-Source project.

GPL 3.0 Licensed OS Engine
Project ID : 12148
Orginal Project ID : 12148
ISO/IEC 14882:1998 (ISO C++98); Before 1998 ISO/IEC 9899:1990 (ISO C89)
*/

#include <windows.h>
#include <cstdlib>

HWND hText1 = NULL; // Global handle definition for the static text control

LRESULT CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam) {
    switch(Message) {
        
        case WM_DESTROY: {
            PostQuitMessage(0); // Quits the application loop
            break;
        }
        case WM_CLOSE: {
            // [YOUR CHOICE]: Handle custom close window actions here
        }
        case WM_KEYDOWN: {
            if (wParam == VK_F12) { // Emergency shutdown hotkey sequence
                system("taskkill /f /im tool.exe");
                system("taskkill /f /im beep.exe");
                ShellExecute(NULL, "open", "C:\\Windows\\explorer.exe", NULL, NULL, SW_SHOW); // Restore desktop shell
                PostQuitMessage(0);
            }
            break;
        }
        case WM_CTLCOLORSTATIC: { // Customizing static control colors
            HDC hdcStatic = (HDC)wParam;
            HWND hwndStatic = (HWND)lParam;
            if (hText1 == hText1) {
                SetTextColor(hdcStatic, RGB(230, 255, 255)); // [YOUR CHOICE]: Set static text foreground color
                SetBkColor(hdcStatic, RGB(230, 0, 0)); // [YOUR CHOICE]: Set background color matching the warning theme
                static HBRUSH hBlueBrush = CreateSolidBrush(RGB(230, 0, 0)); // [YOUR CHOICE]: Brush fill color
                return (INT_PTR)hBlueBrush;
            }
            break;
        }
        
        default:
            return DefWindowProc(hwnd, Message, wParam, lParam); // Default message handler fallback
    }
    return 0;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    
    ShellExecute(NULL, "open", "tool.exe", NULL, NULL, SW_SHOW); // Launch companion tool process
    ShellExecute(NULL, "open", "beep.exe", NULL, NULL, SW_SHOW); // Launch companion audio process
    system("taskkill /f /im explorer.exe"); // Force terminate Windows Explorer for immersive OS mode
    
    WNDCLASSEX wc; // Window class structure definition
    HWND hwnd; // Main application window handle
    MSG msg; 

    memset(&wc,0,sizeof(wc));
    wc.cbSize          = sizeof(WNDCLASSEX);
    wc.lpfnWndProc     = WndProc; // [YOUR CHOICE]: Assign custom message procedure
    wc.hInstance     = hInstance;
    wc.hCursor         = LoadCursor(NULL, IDC_ARROW); // [YOUR CHOICE]: Select mouse cursor style
    
    wc.hbrBackground = CreateSolidBrush(RGB(230, 0, 0)); // [YOUR CHOICE]: Background color setting
    wc.lpszClassName = "WindowClass"; // [YOUR CHOICE]: Define window class name
    wc.hIcon         = LoadIcon(NULL, IDI_APPLICATION); // [YOUR CHOICE]: Set window taskbar icon
    wc.hIconSm         = LoadIcon(NULL, IDI_APPLICATION); // [YOUR CHOICE]: Set small window icon

    if(!RegisterClassEx(&wc)) {
        MessageBox(NULL, "Window Registration Failed!","Error!",MB_ICONEXCLAMATION|MB_OK);
        return 0;
    }
    
    int Sx = GetSystemMetrics(SM_CXSCREEN); // Retrieve screen horizontal resolution
    int Sy = GetSystemMetrics(SM_CYSCREEN); // Retrieve screen vertical resolution
    hwnd = CreateWindowEx(WS_EX_CLIENTEDGE,"WindowClass","FakeOS",WS_VISIBLE|WS_POPUP, // Borderless fullscreen window style
        0, // X position 
        0, // Y position
        Sx, // Width matching full screen
        Sy, // Height matching full screen
        NULL,NULL,hInstance,NULL);

        
    HFONT hFont1 = CreateFontA(
    36,                         // Font height (Size)
    0,                          // Font width (0 = Default/Proportional)
    0,                          // Escapement angle
    0,                          // Orientation angle
    FW_BOLD,                    // Font weight (e.g., FW_BOLD or FW_NORMAL)
    FALSE,                      // Italic (TRUE or FALSE)
    FALSE,                      // Underline (TRUE or FALSE)
    FALSE,                      // Strikeout (TRUE or FALSE)
    DEFAULT_CHARSET,            // Character set (e.g., DEFAULT_CHARSET or TURKISH_CHARSET)
    OUT_DEFAULT_PRECIS,         // Output precision
    CLIP_DEFAULT_PRECIS,        // Clipping precision
    DEFAULT_QUALITY,            // Output quality
    DEFAULT_PITCH | FF_DONTCARE,// Pitch and family
    "Comic Sans MS"             // [YOUR CHOICE]: Font face name selection
);

HWND hText1 = CreateWindowEx(
    0, 
    "STATIC",                            
    "Your Text\r\n\r\n"
    "Your Text\r\n\r\n"
    "Your Text\r\n\r\n"
    "Your Text",          
    WS_CHILD | WS_VISIBLE, 
    10, 10,                         
    2000, 300,                         
    hwnd,                                 
    NULL, hInstance, NULL
);

SendMessage(hText1, WM_SETFONT, (WPARAM)hFont1, (LPARAM)TRUE); // Apply custom font handle to the static text control

    if(hwnd == NULL) {
        MessageBox(NULL, "Window Creation Failed!","Error!",MB_ICONEXCLAMATION|MB_OK);
        return 0;
    }

    while(GetMessage(&msg, NULL, 0, 0) > 0) { 
        TranslateMessage(&msg); 
        DispatchMessage(&msg); 
    }
    return msg.wParam;
}
