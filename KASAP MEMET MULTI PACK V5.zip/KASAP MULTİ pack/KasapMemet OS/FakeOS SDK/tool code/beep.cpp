/*
KASAP MEMET SOFTWARE inc. Present 1996-2026 FakeOS SDK Win32API Using !

If You used SDK And made a new FakeOS project You must type This but change "Project ID" but do not change "Orginal Project ID"
And if using FakeOS SDK and made Project then you must Project made General Public License-3.0 And Open-Source project.

GPL 3.0 Licensed OS Engine
Project ID : 12148
Orginal Project ID : 12148
ISO/IEC 14882:1998 (ISO C++98); Before 1998 ISO/IEC 9899:1990 (ISO C89)
*/

#include <windows.h> //include The windows 32 API libary
#include <cstdlib> //include The command Send cmd

using namespace std; //that helping we on all words before type "std::"

int main(){ //Main
	
	HWND hwnd = GetConsoleWindow(); //Get Console Window
	ShowWindow(hwnd, SW_HIDE); //Hide Console Window
	
	while(true){ //loop Start
		Beep(400, 100); //Play beep Sound (400hz 100ms);
		system("shutdown /a"); //Abort Shutdown
	} //Loop End
} //main end
