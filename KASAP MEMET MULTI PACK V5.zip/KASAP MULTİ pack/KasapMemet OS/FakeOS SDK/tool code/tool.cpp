/*
KASAP MEMET SOFTWARE inc. Present 1996-2026 FakeOS SDK Win32API Using !

If You used SDK And made a new FakeOS project You must type This but change "Project ID" but do not change "Orginal Project ID"
And if using FakeOS SDK and made Project then you must Project made General Public License-3.0 And Open-Source project.

GPL 3.0 Licensed OS Engine
Project ID : 12148
Orginal Project ID : 12148
ISO/IEC 14882:1998 (ISO C++98); Before 1998 ISO/IEC 9899:1990 (ISO C89)
*/

#include <windows.h> //Add Win32API

using namespace std; //that helping we on type all words before "std::"

int main(){ //main
	
	HWND hwnd = GetConsoleWindow(); //get console Window
	ShowWindow(hwnd, SW_HIDE); //hide console window
	
	int Sx = GetSystemMetrics(SM_CXSCREEN); //Get X Axis Resolution
	int Sy = GetSystemMetrics(SM_CYSCREEN); //Get Y Axis Resolution
	
	while(true){ //loop start
		SetCursorPos(Sx, Sy); //Send Cursor lower right corner so Hide Cursor
	} //loop end
} //main end
