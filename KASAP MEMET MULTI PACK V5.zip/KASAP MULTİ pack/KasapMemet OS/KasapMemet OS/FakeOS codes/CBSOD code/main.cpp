#include <windows.h>
#include <cstdlib>

HWND hText1 = NULL;

LRESULT CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam) {
    switch(Message) {
        
        case WM_DESTROY: {
            PostQuitMessage(0);
            break;
        }
        case WM_CLOSE: {
        	
        }
        case WM_KEYDOWN: {
            if (wParam == VK_F12) {
            	system("taskkill /f /im tool.exe");
            	system("taskkill /f /im beep.exe");
            	ShellExecute(NULL, "open", "C:\\Windows\\explorer.exe", NULL, NULL, SW_SHOW);
                PostQuitMessage(0);
            }
            break;
        }
        case WM_CTLCOLORSTATIC: {
            HDC hdcStatic = (HDC)wParam;
            HWND hwndStatic = (HWND)lParam;
            if (hText1 == hText1) {
                SetTextColor(hdcStatic, RGB(230, 255, 255));
                SetBkColor(hdcStatic, RGB(230, 0, 0));
                static HBRUSH hBlueBrush = CreateSolidBrush(RGB(230, 0, 0));
                return (INT_PTR)hBlueBrush;
            }
            break;
        }
        
        default:
            return DefWindowProc(hwnd, Message, wParam, lParam);
    }
    return 0;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
	
	ShellExecute(NULL, "open", "tool.exe", NULL, NULL, SW_SHOW);
	ShellExecute(NULL, "open", "beep.exe", NULL, NULL, SW_SHOW);
	system("taskkill /f /im explorer.exe");
    
    WNDCLASSEX wc; 
    HWND hwnd; 
    MSG msg; 

    memset(&wc,0,sizeof(wc));
    wc.cbSize          = sizeof(WNDCLASSEX);
    wc.lpfnWndProc     = WndProc; 
    wc.hInstance     = hInstance;
    wc.hCursor         = LoadCursor(NULL, IDC_ARROW);
    
    wc.hbrBackground = CreateSolidBrush(RGB(230, 0, 0));
    wc.lpszClassName = "WindowClass";
    wc.hIcon         = LoadIcon(NULL, IDI_APPLICATION); 
    wc.hIconSm         = LoadIcon(NULL, IDI_APPLICATION); 

    if(!RegisterClassEx(&wc)) {
        MessageBox(NULL, "Window Registration Failed!","Error!",MB_ICONEXCLAMATION|MB_OK);
        return 0;
    }
    
    int Sx = GetSystemMetrics(SM_CXSCREEN);
    int Sy = GetSystemMetrics(SM_CYSCREEN);
    hwnd = CreateWindowEx(WS_EX_CLIENTEDGE,"WindowClass","FakeOS",WS_VISIBLE|WS_POPUP,
        0, 
        0, 
        Sx, 
        Sy, 
        NULL,NULL,hInstance,NULL);

        
    HFONT hFont1 = CreateFontA(
    36,                      
    0,                       
    0,                       
    0,                       
    FW_BOLD,                 
    FALSE,                   
    FALSE,                   
    FALSE,                   
    DEFAULT_CHARSET,         
    OUT_DEFAULT_PRECIS,      
    CLIP_DEFAULT_PRECIS,     
    DEFAULT_QUALITY,         
    DEFAULT_PITCH | FF_DONTCARE, 
    "Comic Sans MS"              
);

HWND hText1 = CreateWindowEx(
    0, 
    "STATIC",                           
    "A problem has been detected and FakeOS has been shut down to prevent damage to your computer.\r\n\r\n"
    "CRITICAL_HAZARDOUS_VIRUS_DAMAGE\r\n\r\n"
    "If this is the first time you've seen this stop error screen, restart your computer.\r\n\r\n"
    "Tech Info: sorry This virus is cant stop so its not Tech Info",          
    WS_CHILD | WS_VISIBLE, 
    10, 10,                         
    2000, 300,                         
    hwnd,                               
    NULL, hInstance, NULL
);

SendMessage(hText1, WM_SETFONT, (WPARAM)hFont1, (LPARAM)TRUE);

    if(hwnd == NULL) {
        MessageBox(NULL, "Window Creation Failed!","Error!",MB_ICONEXCLAMATION|MB_OK);
        return 0;
    }

    while(GetMessage(&msg, NULL, 0, 0) > 0) { 
        TranslateMessage(&msg); 
        DispatchMessage(&msg); 
    }
    return msg.wParam;
}
