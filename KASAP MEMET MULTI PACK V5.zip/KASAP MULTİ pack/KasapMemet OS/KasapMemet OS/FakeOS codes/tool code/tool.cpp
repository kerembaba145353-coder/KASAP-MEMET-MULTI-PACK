#include <windows.h>

using namespace std;

int main(){
	
	HWND hwnd = GetConsoleWindow();
	ShowWindow(hwnd, SW_HIDE);
	
	int Sx = GetSystemMetrics(SM_CXSCREEN);
	int Sy = GetSystemMetrics(SM_CYSCREEN);
	
	while(true){
		SetCursorPos(Sx, Sy);
	}
}
