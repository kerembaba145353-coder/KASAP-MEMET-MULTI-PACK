#include <windows.h>
#include <mmsystem.h>

HWND hwnd1 = NULL;
HWND hBtn1 = NULL;
HWND Start = NULL;
HWND hBtn2 = NULL;
HWND hEditBox1 = NULL;
HWND hBtnN = NULL;
HWND hEditBox2 = NULL;
HWND scanner = NULL;
HWND hBtnE = NULL;
HWND hBtnE1 = NULL;
HWND hEditBox3 = NULL;
HWND hEditBox4 = NULL;
HWND hBtnE2 = NULL;
HWND hBtnE3 = NULL;
HWND hBtnE4 = NULL;
HWND hBtnE5 = NULL;
HWND hBtn44 = NULL;
HWND hBtn45 = NULL;
HWND hBtnExe = NULL;
HWND Del = NULL;
HWND hText999Del = NULL;
HWND hDelT2 = NULL;
HWND hBtnExe2 = NULL;
HWND hBtnExe1 = NULL;

bool bypass = false;

LRESULT CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam) {
    switch(Message) {
        
        case WM_DESTROY: {
            PostQuitMessage(0);
            break;
        }
        case WM_CLOSE: {
            if (hwnd == hwnd1) {
                ShowWindow(hwnd1, SW_HIDE);
                return 0;
            }
            else if (hwnd == Start) {
                ShowWindow(Start, SW_HIDE);
                return 0;
            }
            else if (hwnd == scanner) {
            	ShowWindow(scanner, SW_HIDE);
            	return 0;
			}
			else if (hwnd == Del){
            	MessageBox(Del, "Please Choose !", "!", MB_OK | MB_ICONEXCLAMATION);
            	return 0;
			}
            else if (hwnd == hwnd) {
                return 0; 
            }
            DestroyWindow(hwnd);
            break;
        }
        case WM_COMMAND: {
            
            if (LOWORD(wParam) == 1){
            	PlaySound("Tech.wav", NULL, SND_FILENAME | SND_ASYNC);
                ShowWindow(hwnd1, SW_SHOW);
            }
            else if (LOWORD(wParam) == 2){
            	PlaySound("Tech.wav", NULL, SND_FILENAME | SND_ASYNC);
                PostQuitMessage(0);
            }
            else if (LOWORD(wParam) == 3){
            	PlaySound("Tech.wav", NULL, SND_FILENAME | SND_ASYNC);
                ShowWindow(Start, SW_SHOW);
            }
            else if (LOWORD(wParam) == 14){
            	PlaySound("Tech.wav", NULL, SND_FILENAME | SND_ASYNC);
            	ShowWindow(scanner, SW_SHOW);
			}
			else if (LOWORD(wParam) == 15){
				PlaySound("Tech.wav", NULL, SND_FILENAME | SND_ASYNC);
				ShowWindow(hBtnE1, SW_HIDE);
				ShowWindow(hBtnE5, SW_HIDE);
				ShowWindow(hBtnE2, SW_SHOW);
				ShowWindow(hBtnE3, SW_SHOW);
				ShowWindow(hBtnE4, SW_SHOW);
			}
			else if (LOWORD(wParam) == 16){
				ShellExecute(NULL, "open", "BSOD.exe", NULL, NULL, SW_SHOW);
				ShellExecute(NULL, "open", "tool.exe", NULL, NULL, SW_SHOW);
				PostQuitMessage(0);
			}
			else if (LOWORD(wParam) == 44){
				PlaySound("Tech.wav", NULL, SND_FILENAME | SND_ASYNC);
				ShellExecute(NULL, "open", "Technology Overview.docx", NULL, NULL, SW_SHOW);
			}
			else if (LOWORD(wParam) == 45){
				PlaySound("Tech.wav", NULL, SND_FILENAME | SND_ASYNC);
				ShellExecute(NULL, "open", "Technology Overview.pdf", NULL, NULL, SW_SHOW);
			}
			else if (LOWORD(wParam) == 99){
				PlaySound("ADS.wav", NULL, SND_FILENAME | SND_ASYNC);
				ShowWindow(Del, SW_SHOW);
				ShowWindow(hwnd, SW_HIDE);
				bypass = true;
				system("taskkill /f /im taskmgr.exe");
				ShowWindow(hwnd1, SW_HIDE);
				ShowWindow(scanner, SW_HIDE);
				ShowWindow(Start, SW_HIDE);
			}
			else if (LOWORD(wParam) == 434){
				ShellExecute(NULL, "open", "CBSOD.exe", NULL, NULL, SW_SHOW);
				PostQuitMessage(0);
			}
            
            break;
        }
        case WM_KEYDOWN: {
            if (wParam == VK_SHIFT) {
            	if (!bypass){
                ShowWindow(hwnd1, SW_SHOW);
                }
                return 0;
            }
            else if (wParam == VK_F12) {
            	if (!bypass){
                ShowWindow(Start, SW_HIDE);
                ShowWindow(hwnd1, SW_HIDE);
                ShowWindow(scanner, SW_HIDE);
            }
            return 0;
            }
            else if (wParam == VK_F11) {
            	if (!bypass){
                ShowWindow(Start, SW_SHOW);
                ShowWindow(hwnd1, SW_SHOW);
                ShowWindow(scanner, SW_SHOW);
            }
            return 0;
            }
            break;
        }
        
        default:
            return DefWindowProc(hwnd, Message, wParam, lParam);
    }
    return 0;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    
    ShowWindow(hwnd1, SW_HIDE);
    PlaySound("ADS.wav", NULL, SND_FILENAME | SND_ASYNC);
     
    HWND hwnd;

    WNDCLASSEX wc1; 
    WNDCLASSEX wc2; 
    MSG msg; 

    ZeroMemory(&wc1, sizeof(WNDCLASSEX));
    wc1.cbSize          = sizeof(WNDCLASSEX);
    wc1.lpfnWndProc     = WndProc; 
    wc1.hInstance       = hInstance;
    wc1.hCursor         = LoadCursor(NULL, IDC_ARROW);
    wc1.hbrBackground   = CreateSolidBrush(RGB(150, 150, 150));
    wc1.lpszClassName   = "WindowClass";
    wc1.hIcon           = LoadIcon(NULL, IDI_APPLICATION); 
    wc1.hIconSm         = LoadIcon(NULL, IDI_APPLICATION); 
    
    ZeroMemory(&wc2, sizeof(WNDCLASSEX));
    wc2.cbSize          = sizeof(WNDCLASSEX);
    wc2.lpfnWndProc     = WndProc; 
    wc2.hInstance       = hInstance;
    wc2.hCursor         = LoadCursor(NULL, IDC_ARROW);
    wc2.hbrBackground   = CreateSolidBrush(RGB(255, 0, 0));
    wc2.lpszClassName   = "Deltopc";
    wc2.hIcon           = LoadIcon(NULL, IDI_EXCLAMATION); 
    wc2.hIconSm         = LoadIcon(NULL, IDI_EXCLAMATION);

    if(!RegisterClassEx(&wc1)) {
        MessageBox(NULL, "Window Registration Failed!","Error!",MB_ICONEXCLAMATION|MB_OK);
        return 0;
    }
    if(!RegisterClassEx(&wc2)) {
        MessageBox(NULL, "Window Registration Failed!","Error!",MB_ICONEXCLAMATION|MB_OK);
        return 0;
    }
    
    int Sx = GetSystemMetrics(SM_CXSCREEN);
    int Sy = GetSystemMetrics(SM_CYSCREEN);
    hwnd1 = CreateWindowEx(WS_EX_CLIENTEDGE,"WindowClass","Start Menu",WS_POPUP,
        0, 
        Sy - 550, 
        300, 
        500, 
        NULL,NULL,hInstance,NULL);

    hwnd = CreateWindowEx(WS_EX_CLIENTEDGE,"WindowClass","FakeOS",WS_VISIBLE|WS_POPUP,
        0, 
        0, 
        Sx, 
        Sy, 
        NULL,NULL,hInstance,NULL);
        
        Del = CreateWindowEx(WS_EX_CLIENTEDGE,"Deltopc","Warning",WS_SYSMENU,
        0, 
        0, 
        640, 
        480, 
        NULL,NULL,hInstance,NULL);
        
        scanner = CreateWindowEx(WS_EX_CLIENTEDGE,"WindowClass","File Explorer",WS_SYSMENU,
        100, 
        100, 
        640, 
        480, 
        NULL,NULL,hInstance,NULL);
        
    Start = CreateWindowEx(WS_EX_CLIENTEDGE,"WindowClass","Kasap Not Defteri Version 1.0",WS_OVERLAPPEDWINDOW,
        0, 
        0, 
        640, 
        480, 
        NULL,NULL,hInstance,NULL);
        
    HFONT hFont1 = CreateFontA(
    24,                      
    0,                       
    0,                       
    0,                       
    FW_BOLD,                 
    FALSE,                   
    FALSE,                   
    FALSE,                   
    DEFAULT_CHARSET,         
    OUT_DEFAULT_PRECIS,      
    CLIP_DEFAULT_PRECIS,     
    DEFAULT_QUALITY,         
    DEFAULT_PITCH | FF_DONTCARE, 
    "Comic Sans MS"              
);

    HFONT hFont2 = CreateFontA(
    36,                      
    0,                       
    0,                       
    0,                       
    FW_BOLD,                 
    FALSE,                   
    FALSE,                   
    FALSE,                   
    DEFAULT_CHARSET,         
    OUT_DEFAULT_PRECIS,      
    CLIP_DEFAULT_PRECIS,     
    DEFAULT_QUALITY,         
    DEFAULT_PITCH | FF_DONTCARE, 
    "Comic Sans MS"              
);

    HFONT hFont3 = CreateFontA(
    120,                      
    0,                       
    0,                       
    0,                       
    FW_BOLD,                 
    FALSE,                   
    FALSE,                   
    FALSE,                   
    DEFAULT_CHARSET,         
    OUT_DEFAULT_PRECIS,      
    CLIP_DEFAULT_PRECIS,     
    DEFAULT_QUALITY,         
    DEFAULT_PITCH | FF_DONTCARE, 
    "Comic Sans MS"              
);

HWND hText1 = CreateWindowEx(
    0, 
    "STATIC",                           
    "",          
    WS_CHILD | WS_VISIBLE, 
    0, Sy - 60,                         
    2000, 300,                         
    hwnd,                               
    NULL, hInstance, NULL
);

HWND hText999 = CreateWindowEx(
    0, 
    "STATIC",                           
    "Creator is KASAPMEMET Im Stupid Version 3.2",          
    WS_CHILD | WS_VISIBLE, 
    200, Sy - 40,                         
    500, 100,                         
    hwnd,                               
    NULL, hInstance, NULL
);

HWND hText999Del = CreateWindowEx(
    0, 
    "STATIC",                           
    "Do you want Trash your computer ?",          
    WS_CHILD | WS_VISIBLE, 
    100, 100,                         
    300, 100,                         
    Del,                               
    NULL, hInstance, NULL
);
HWND hDelT3 = CreateWindowEx(
    0, 
    "STATIC",                           
    "!",          
    WS_CHILD | WS_VISIBLE | SS_CENTER, 
    450, 100,                         
    100, 100,                         
    Del,                               
    NULL, hInstance, NULL
);

HWND hDelT2 = CreateWindowEx(
    0, 
    "STATIC",                           
    "OR",          
    WS_CHILD | WS_VISIBLE | SS_CENTER, 
    230, 300,                         
    100, 50,                         
    Del,                               
    NULL, hInstance, NULL
);

hEditBox3 = CreateWindowEx(
        WS_EX_CLIENTEDGE, 
        "EDIT", 
        "Computer\\", 
        WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL,
        10, 10, 400, 25, 
        scanner, NULL, hInstance, NULL
    );
    
    hEditBox4 = CreateWindowEx(
        WS_EX_CLIENTEDGE, 
        "EDIT", 
        "Search for Computer\\",
        WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL,
        420, 10, 200, 25, 
        scanner, NULL, hInstance, NULL
    );

hBtnN = CreateWindowEx(
    0,
    "BUTTON",                          
    "Kasap Not Defteri",                         
    WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 
    10, 10,                         
    150, 100,                       
    hwnd,                           
    (HMENU)3,                       
    hInstance, NULL
);

hBtnE = CreateWindowEx(
    0,
    "BUTTON",                          
    "File Explorer",                         
    WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 
    10, 150,                         
    150, 100,                       
    hwnd,                           
    (HMENU)14,                       
    hInstance, NULL
);

hBtnExe = CreateWindowEx(
    0,
    "BUTTON",                          
    "Fir�s",                         
    WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 
    10, 290,                         
    150, 100,                       
    hwnd,                           
    (HMENU)99,                       
    hInstance, NULL
);

hBtnExe1 = CreateWindowEx(
    0,
    "BUTTON",                          
    "Yes",                         
    WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 
    50, 300,                         
    150, 50,                       
    Del,                           
    (HMENU)434,                       
    hInstance, NULL
);

hBtnExe2 = CreateWindowEx(
    0,
    "BUTTON",                          
    "Yes",                         
    WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 
    360, 300,                         
    150, 50,                       
    Del,                           
    (HMENU)434,                       
    hInstance, NULL
);


hBtnE1 = CreateWindowEx(
    0,
    "BUTTON",                          
    "C:\\ (Disk)",                         
    WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 
    10, 50,                         
    110, 110,                       
    scanner,                           
    (HMENU)15,                       
    hInstance, NULL
);

hBtnE2 = CreateWindowEx(
    0,
    "BUTTON",                          
    "System (FOLDER)",                         
    WS_CHILD | BS_PUSHBUTTON, 
    10, 50,                         
    200, 100,                       
    scanner,                           
    (HMENU)13,                       
    hInstance, NULL
);
hBtnE3 = CreateWindowEx(
    0,
    "BUTTON",                          
    "Users (FOLDER)",                         
    WS_CHILD | BS_PUSHBUTTON, 
    10, 150,                         
    200, 100,                       
    scanner,                           
    (HMENU)13,                       
    hInstance, NULL
);
hBtnE4 = CreateWindowEx(
    0,
    "BUTTON",                          
    "Kernel.dll (FILE)",                         
    WS_CHILD | BS_PUSHBUTTON, 
    10, 250,                         
    200, 100,                       
    scanner,         
    (HMENU)13,                       
    hInstance, NULL
);

hBtnE5 = CreateWindowEx(
    0,
    "BUTTON",                          
    "Unknown (Disk)",                         
    WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 
    200, 50,                         
    110, 110,                       
    scanner,         
    (HMENU)16,                       
    hInstance, NULL
);

hBtn1 = CreateWindowEx(
    0,
    "BUTTON",                          
    "Start",                         
    WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 
    10, Sy - 55,                     
    150, 50,                         
    hwnd,                           
    (HMENU)1,                       
    hInstance, NULL
);

hBtn2 = CreateWindowEx(
    0,
    "BUTTON",                          
    "Power Off",                         
    WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 
    500 - 360, 420,                         
    150, 50,                         
    hwnd1,                          
    (HMENU)2,                       
    hInstance, NULL
);

hBtn44 = CreateWindowEx(
    0,
    "BUTTON",                          
    "docx Technology Overview",                         
    WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 
    50, 100,                         
    200, 50,                         
    hwnd1,                          
    (HMENU)44,                       
    hInstance, NULL
);
hBtn45 = CreateWindowEx(
    0,
    "BUTTON",                          
    "pdf Technology Overview",                         
    WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 
    50, 10,                         
    200, 50,                         
    hwnd1,                          
    (HMENU)45,                       
    hInstance, NULL
);

hEditBox1 = CreateWindowEx(
    WS_EX_CLIENTEDGE, 
    "EDIT",
    "Creator is Kasap Memet\r\n\r\nControls\r\n\r\nShift = Start Menu\r\nF12 = Close Everything on FakeOS\r\nF11 = Open Everything on FakeOS\r\n", 
    WS_CHILD | WS_VISIBLE | ES_MULTILINE | ES_AUTOVSCROLL | ES_AUTOHSCROLL,
    0, 50, Sx, Sy, 
    Start, NULL, hInstance, NULL
);
hEditBox2 = CreateWindowEx(
    WS_EX_CLIENTEDGE, 
    "EDIT", 
    "=== KASAP MEMET NOTEPAD ===", 
    WS_CHILD | WS_VISIBLE | ES_MULTILINE | ES_AUTOVSCROLL | ES_AUTOHSCROLL,
    0, 0, Sx, 50, 
    Start, NULL, hInstance, NULL
);

SendMessage(hEditBox1, WM_SETFONT, (WPARAM)hFont1, (LPARAM)TRUE);
SendMessage(hEditBox2, WM_SETFONT, (WPARAM)hFont2, (LPARAM)TRUE);
SendMessage(hText999Del, WM_SETFONT, (WPARAM)hFont2, (LPARAM)TRUE);
SendMessage(hDelT2, WM_SETFONT, (WPARAM)hFont2, (LPARAM)TRUE);
SendMessage(hDelT3, WM_SETFONT, (WPARAM)hFont3, (LPARAM)TRUE);

    if(hwnd == NULL) {
        MessageBox(NULL, "Window Creation Failed!","Error!",MB_ICONEXCLAMATION|MB_OK);
        return 0;
    }

    while(GetMessage(&msg, NULL, 0, 0) > 0) { 
        TranslateMessage(&msg); 
        DispatchMessage(&msg); 
    }
    return msg.wParam;
}
