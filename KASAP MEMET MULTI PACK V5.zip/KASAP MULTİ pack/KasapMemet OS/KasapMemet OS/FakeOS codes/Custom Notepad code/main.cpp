#include <windows.h>

HWND Start = NULL;
HWND hEditBox1 = NULL;
HWND hEditBox2 = NULL;

LRESULT CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam) {
    switch(Message) {
        case WM_DESTROY: {
            PostQuitMessage(0);
            break;
        }
        case WM_CLOSE: {
            DestroyWindow(hwnd);
            break;
        }
        default:
            return DefWindowProc(hwnd, Message, wParam, lParam);
    }
    return 0;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    WNDCLASSEX wc; 
    HWND hwnd; 
    MSG msg; 

    memset(&wc, 0, sizeof(wc));
    wc.cbSize          = sizeof(WNDCLASSEX);
    wc.lpfnWndProc     = WndProc; 
    wc.hInstance     = hInstance;
    wc.hCursor         = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = CreateSolidBrush(RGB(255, 140, 0));
    wc.lpszClassName = "NotepadClass";
    wc.hIcon         = LoadIcon(NULL, IDI_APPLICATION); 
    wc.hIconSm       = LoadIcon(NULL, IDI_APPLICATION); 

    if(!RegisterClassEx(&wc)) {
        MessageBox(NULL, "Window Registration Failed!", "Error!", MB_ICONEXCLAMATION | MB_OK);
        return 0;
    }

    Start = CreateWindowEx(
        WS_EX_CLIENTEDGE, 
        "NotepadClass", 
        "Kasap Not Defteri Version 1.0", 
        WS_OVERLAPPEDWINDOW | WS_VISIBLE,
        CW_USEDEFAULT, CW_USEDEFAULT, 
        640, 480, 
        NULL, NULL, hInstance, NULL
    );
        
    HFONT hFont1 = CreateFontA(
        24, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, 
        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, 
        DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Comic Sans MS"
    );

    HFONT hFont2 = CreateFontA(
        36, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, 
        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, 
        DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Comic Sans MS"
    );

    hEditBox1 = CreateWindowEx(
        WS_EX_CLIENTEDGE, 
        "EDIT",
        "Creator is Kasap Memet", 
        WS_CHILD | WS_VISIBLE | ES_MULTILINE | ES_AUTOVSCROLL | ES_AUTOHSCROLL,
        0, 50, 640, 430, 
        Start, NULL, hInstance, NULL
    );

    hEditBox2 = CreateWindowEx(
        WS_EX_CLIENTEDGE, 
        "EDIT", 
        "=== KASAP MEMET NOTEPAD ===", 
        WS_CHILD | WS_VISIBLE | ES_MULTILINE | ES_AUTOVSCROLL | ES_AUTOHSCROLL,
        0, 0, 640, 50, 
        Start, NULL, hInstance, NULL
    );

    SendMessage(hEditBox1, WM_SETFONT, (WPARAM)hFont1, (LPARAM)TRUE);
    SendMessage(hEditBox2, WM_SETFONT, (WPARAM)hFont2, (LPARAM)TRUE);

    while(GetMessage(&msg, NULL, 0, 0) > 0) { 
        TranslateMessage(&msg); 
        DispatchMessage(&msg); 
    }
    return msg.wParam;
}
