@echo off
cd /d "%~dp0"
:loop
cls
title OFF/ON realistic BSOD

echo Optimize = 0
echo realistic = 1
SET /P RT="MOD SELECT (1/0) : "

if "%RT%"=="1" (
echo [!] Realistic mod Running...
taskkill /f /im tool1.exe
taskkill /f /im beep1.exe
ren tool1.exe tool.exe
ren beep1.exe beep.exe
echo Running FakeOS.exe...
timeout /t 2 /nobreak
start FakeOS.exe
exit
) else if "%RT%"=="0" (
echo [!] Optimize mod Running...
taskkill /f /im tool.exe
taskkill /f /im beep.exe
ren tool.exe tool1.exe
ren beep.exe beep1.exe
echo Running FakeOS.exe...
timeout /t 2 /nobreak
start FakeOS.exe
exit
) else (
cls
echo Just select 0 or 1
timeout /t 2 >nul
goto loop
)