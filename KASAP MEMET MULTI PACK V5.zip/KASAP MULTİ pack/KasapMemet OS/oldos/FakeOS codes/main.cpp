#include <windows.h>

HWND hwnd1 = NULL;
HWND hBtn1 = NULL;
HWND Start = NULL;
HWND hBtn2 = NULL;
HWND hEditBox1 = NULL;
HWND hBtnN = NULL;
HWND hEditBox2 = NULL;

LRESULT CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam) {
    switch(Message) {
        
        case WM_DESTROY: {
            PostQuitMessage(0);
            break;
        }
        case WM_CLOSE: {
            if (hwnd == hwnd1) {
                ShowWindow(hwnd1, SW_HIDE);
                return 0;
            }
            else if (hwnd == Start) {
                ShowWindow(Start, SW_HIDE);
                return 0;
            }
            else if (hwnd == hwnd) {
                return 0; 
            }
            
            DestroyWindow(hwnd);
            break;
        }
        case WM_COMMAND: {
            
            if (LOWORD(wParam) == 1){
                ShowWindow(hwnd1, SW_SHOW);
            }
            else if (LOWORD(wParam) == 2){
                PostQuitMessage(0);
            }
            else if (LOWORD(wParam) == 3){
                ShowWindow(Start, SW_SHOW);
            }
            
            break;
        }
        case WM_KEYDOWN: {
            if (wParam == VK_SHIFT) {
                ShowWindow(hwnd1, SW_SHOW);
            }
            else if (wParam == VK_F12) {
                ShowWindow(Start, SW_HIDE);
                ShowWindow(hwnd1, SW_HIDE);
            }
            else if (wParam == VK_F11) {
                ShowWindow(Start, SW_SHOW);
                ShowWindow(hwnd1, SW_SHOW);
            }
            break;
        }
        
        default:
            return DefWindowProc(hwnd, Message, wParam, lParam);
    }
    return 0;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    
    ShowWindow(hwnd1, SW_HIDE);
    
    WNDCLASSEX wc; 
    HWND hwnd; 
    MSG msg; 

    memset(&wc,0,sizeof(wc));
    wc.cbSize          = sizeof(WNDCLASSEX);
    wc.lpfnWndProc     = WndProc; 
    wc.hInstance     = hInstance;
    wc.hCursor         = LoadCursor(NULL, IDC_ARROW);
    
    wc.hbrBackground = CreateSolidBrush(RGB(255, 140, 0));
    wc.lpszClassName = "WindowClass";
    wc.hIcon         = LoadIcon(NULL, IDI_APPLICATION); 
    wc.hIconSm         = LoadIcon(NULL, IDI_APPLICATION); 

    if(!RegisterClassEx(&wc)) {
        MessageBox(NULL, "Window Registration Failed!","Error!",MB_ICONEXCLAMATION|MB_OK);
        return 0;
    }
    
    int Sx = GetSystemMetrics(SM_CXSCREEN);
    int Sy = GetSystemMetrics(SM_CYSCREEN);
    hwnd1 = CreateWindowEx(WS_EX_CLIENTEDGE,"WindowClass","Start Menu",WS_SYSMENU,
        0, 
        Sy - 550, 
        300, 
        500, 
        NULL,NULL,hInstance,NULL);

    hwnd = CreateWindowEx(WS_EX_CLIENTEDGE,"WindowClass","? NEDEN ?",WS_VISIBLE|WS_POPUP,
        0, 
        0, 
        Sx, 
        Sy, 
        NULL,NULL,hInstance,NULL);
        
    Start = CreateWindowEx(WS_EX_CLIENTEDGE,"WindowClass","Kasap Not Defteri Version 1.0",WS_OVERLAPPEDWINDOW,
        0, 
        0, 
        640, 
        480, 
        NULL,NULL,hInstance,NULL);
        
    HFONT hFont1 = CreateFontA(
    24,                      
    0,                       
    0,                       
    0,                       
    FW_BOLD,                 
    FALSE,                   
    FALSE,                   
    FALSE,                   
    DEFAULT_CHARSET,         
    OUT_DEFAULT_PRECIS,      
    CLIP_DEFAULT_PRECIS,     
    DEFAULT_QUALITY,         
    DEFAULT_PITCH | FF_DONTCARE, 
    "Comic Sans MS"              
);

    HFONT hFont2 = CreateFontA(
    36,                      
    0,                       
    0,                       
    0,                       
    FW_BOLD,                 
    FALSE,                   
    FALSE,                   
    FALSE,                   
    DEFAULT_CHARSET,         
    OUT_DEFAULT_PRECIS,      
    CLIP_DEFAULT_PRECIS,     
    DEFAULT_QUALITY,         
    DEFAULT_PITCH | FF_DONTCARE, 
    "Comic Sans MS"              
);

HWND hText1 = CreateWindowEx(
    0, 
    "STATIC",                           
    "",          
    WS_CHILD | WS_VISIBLE, 
    0, Sy - 60,                         
    2000, 300,                         
    hwnd,                               
    NULL, hInstance, NULL
);

hBtnN = CreateWindowEx(
    0,
    "BUTTON",                          
    "Kasap Not Defteri",                         
    WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 
    10, 10,                         
    150, 100,                       
    hwnd,                           
    (HMENU)3,                       
    hInstance, NULL
);

hBtn1 = CreateWindowEx(
    0,
    "BUTTON",                          
    "Start",                         
    WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 
    10, Sy - 55,                     
    150, 50,                         
    hwnd,                           
    (HMENU)1,                       
    hInstance, NULL
);

hBtn2 = CreateWindowEx(
    0,
    "BUTTON",                          
    "Power Off",                         
    WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 
    500 - 360, 420,                         
    150, 50,                         
    hwnd1,                          
    (HMENU)2,                       
    hInstance, NULL
);

hEditBox1 = CreateWindowEx(
    WS_EX_CLIENTEDGE, 
    "EDIT",
    "Creator is Kasap Memet\r\n\r\nControls\r\n\r\nShift = Start Menu\r\nF12 = Close Every Thing on FakeOS\r\nF11 = Open Everything on FakeOS\r\n", 
    WS_CHILD | WS_VISIBLE | ES_MULTILINE | ES_AUTOVSCROLL | ES_AUTOHSCROLL,
    0, 50, Sx, Sy, 
    Start, NULL, hInstance, NULL
);
hEditBox2 = CreateWindowEx(
    WS_EX_CLIENTEDGE, 
    "EDIT", 
    "=== KASAP MEMET NOTEPAD ===", 
    WS_CHILD | WS_VISIBLE | ES_MULTILINE | ES_AUTOVSCROLL | ES_AUTOHSCROLL,
    0, 0, Sx, 50, 
    Start, NULL, hInstance, NULL
);

SendMessage(hEditBox1, WM_SETFONT, (WPARAM)hFont1, (LPARAM)TRUE);
SendMessage(hEditBox2, WM_SETFONT, (WPARAM)hFont2, (LPARAM)TRUE);

    if(hwnd == NULL) {
        MessageBox(NULL, "Window Creation Failed!","Error!",MB_ICONEXCLAMATION|MB_OK);
        return 0;
    }

    while(GetMessage(&msg, NULL, 0, 0) > 0) { 
        TranslateMessage(&msg); 
        DispatchMessage(&msg); 
    }
    return msg.wParam;
}
