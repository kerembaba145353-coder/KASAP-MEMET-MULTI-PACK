#include <iostream>
#include <windows.h>
#include <string>
#include <cstdlib>
#include <mmsystem.h>

using namespace std;

int main(){
	
	HWND hWnd = GetConsoleWindow();
	ShowWindow(hWnd, SW_HIDE);
	
	while(true){
	PlaySound("tiny.wav", NULL, SND_FILENAME | SND_SYNC);
    }
}
