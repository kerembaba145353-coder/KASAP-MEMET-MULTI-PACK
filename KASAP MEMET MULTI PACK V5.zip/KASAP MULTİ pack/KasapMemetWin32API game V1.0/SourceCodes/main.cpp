#include <windows.h>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <ctime>

int Xs = GetSystemMetrics(SM_CXSCREEN);
int Ys = GetSystemMetrics(SM_CYSCREEN);
bool isGameStarted = false;
bool isJumping = false;
float PlayerX = 100;
float PlayerY = 300;
float gravity = 0;
float gameGravityFactor = 0.6f; 
bool pause = false;
bool isFullscreen = true;

std::string menuPath = "Must\\models\\menu.bmp";
std::string playerPath = "Must\\models\\player.bmp";

struct Platform {
    int x, y, w, h;
};

Platform platforms[] = {
    { 50, 450, 700, 30 },
    { 200, 350, 150, 20 },
    { 400, 260, 150, 20 },
    { 250, 170, 120, 20 },
    { 500, 100, 150, 20 }
};

HWND hBtn, hBtn2, hBtn3, hBtn4, hBtnSettings;
HWND hRes1, hRes2, hRes3, hRes4, hRes5, hRes6, hBtnFullscreen, hBackToMenu;
HBITMAP hPlayerBitmap = NULL;
HBITMAP hMenuBitmap = NULL;

void RandomizePlatforms() {
    for (int i = 0; i < 5; i++) {
        if (i == 0) {
            platforms[i].y = 450 + (rand() % 21 - 10); 
        } else {
            int randomOffset = (rand() % 31) - 15; 
            platforms[i].y += randomOffset;
            
            if (platforms[i].y < 50) platforms[i].y = 50;
            if (platforms[i].y > Ys - 100) platforms[i].y = Ys - 100;
        }
    }
}

void SaveConfig(int width, int height, bool fullscreen, float grav, std::string mPath, std::string pPath) {
    std::ofstream file("Must/config.ini");
    if (file.is_open()) {
        file << "Width=" << width << "\n";
        file << "Height=" << height << "\n";
        file << "Fullscreen=" << (fullscreen ? 1 : 0) << "\n";
        file << "Gravity=" << grav << "\n";
        file << "MenuPath=" << mPath << "\n";
        file << "PlayerPath=" << pPath << "\n";
        file.close();
    }
}

void LoadConfig(int &width, int &height, bool &fullscreen, float &grav, std::string &mPath, std::string &pPath) {
    std::ifstream file("Must/config.ini");
    if (!file.is_open()) {
        width = GetSystemMetrics(SM_CXSCREEN);
        height = GetSystemMetrics(SM_CYSCREEN);
        fullscreen = true;
        grav = 0.6f;
        mPath = "Must\\models\\menu.bmp";
        pPath = "Must\\models\\player.bmp";
        SaveConfig(width, height, fullscreen, grav, mPath, pPath);
        return;
    }

    std::string line;
    while (std::getline(file, line)) {
        size_t delimiterPos = line.find('=');
        if (delimiterPos != std::string::npos) {
            std::string key = line.substr(0, delimiterPos);
            std::string valueStr = line.substr(delimiterPos + 1);
            
            key.erase(0, key.find_first_not_of(" \t\r\n"));
            key.erase(key.find_last_not_of(" \t\r\n") + 1);
            valueStr.erase(0, valueStr.find_first_not_of(" \t\r\n"));
            valueStr.erase(valueStr.find_last_not_of(" \t\r\n") + 1);

            if (!valueStr.empty()) {
                if (key == "Width") {
                    std::stringstream ss(valueStr);
                    ss >> width;
                }
                else if (key == "Height") {
                    std::stringstream ss(valueStr);
                    ss >> height;
                }
                else if (key == "Fullscreen") {
                    std::stringstream ss(valueStr);
                    int val = 0;
                    if (ss >> val) fullscreen = (val != 0);
                }
                else if (key == "Gravity") {
                    std::stringstream ss(valueStr);
                    ss >> grav;
                }
                else if (key == "MenuPath") {
                    mPath = valueStr;
                }
                else if (key == "PlayerPath") {
                    pPath = valueStr;
                }
            }
        }
    }
    file.close();
}

void ChangeResolution(HWND hwnd, int width, int height, bool fullscreen) {
    if (fullscreen) {
        SetWindowLongPtr(hwnd, GWL_STYLE, WS_POPUP | WS_VISIBLE);
        SetWindowPos(hwnd, HWND_TOP, 0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), SWP_SHOWWINDOW);
        Xs = GetSystemMetrics(SM_CXSCREEN);
        Ys = GetSystemMetrics(SM_CYSCREEN);
        isFullscreen = true;
    } else {
        SetWindowLongPtr(hwnd, GWL_STYLE, WS_OVERLAPPEDWINDOW | WS_VISIBLE);
        SetWindowPos(hwnd, HWND_TOP, 100, 100, width, height, SWP_SHOWWINDOW);
        Xs = width;
        Ys = height;
        isFullscreen = false;
    }
    SaveConfig(Xs, Ys, isFullscreen, gameGravityFactor, menuPath, playerPath);
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam) {
    switch(Message) {
        
        case WM_COMMAND: {
            int id = LOWORD(wParam);

            if (id == 1) { 
                MessageBox(hwnd, "The Creator is KASAPMEMET version v1.0 im 7th Grade Student 12 years old but im stupid !", "About", MB_OK | MB_ICONEXCLAMATION);
            }
            else if (id == 2) { 
                MessageBox(hwnd, "Why Are You Going here !", "KasapMemetGame.exe", MB_OK | MB_ICONSTOP);
                isGameStarted = true;
                pause = false;
                RandomizePlatforms(); 
                ShowWindow(hBtn, SW_HIDE);
                ShowWindow(hBtn2, SW_HIDE);
                ShowWindow(hBtn3, SW_HIDE);
                ShowWindow(hBtnSettings, SW_HIDE);
                ShowWindow(hBtn4, SW_HIDE);
                SetFocus(hwnd);
            }
            else if (id == 3) { 
                int msgID = MessageBox(hwnd, "Are You Sure The exit game (This Project Unsave) !", "Warning", MB_YESNO | MB_ICONEXCLAMATION);
                if (msgID == IDYES){
                    system("taskkill /f /im msc.exe");
                    PostQuitMessage(0);
                }
            }
            else if (id == 4) { 
                pause = false;
                ShowWindow(hBtn4, SW_HIDE);
                SetFocus(hwnd);
            }
            else if (id == 5) { 
                ShowWindow(hBtn, SW_HIDE);
                ShowWindow(hBtn2, SW_HIDE);
                ShowWindow(hBtn3, SW_HIDE);
                ShowWindow(hBtnSettings, SW_HIDE);

                ShowWindow(hRes1, SW_SHOW);
                ShowWindow(hRes2, SW_SHOW);
                ShowWindow(hRes3, SW_SHOW);
                ShowWindow(hRes4, SW_SHOW);
                ShowWindow(hRes5, SW_SHOW);
                ShowWindow(hRes6, SW_SHOW);
                ShowWindow(hBtnFullscreen, SW_SHOW);
                ShowWindow(hBackToMenu, SW_SHOW);
            }
            else if (id == 10) { ChangeResolution(hwnd, 640, 480, false); }
            else if (id == 11) { ChangeResolution(hwnd, 800, 600, false); }
            else if (id == 12) { ChangeResolution(hwnd, 1024, 768, false); }
            else if (id == 13) { ChangeResolution(hwnd, 1280, 720, false); }
            else if (id == 14) { ChangeResolution(hwnd, 1366, 768, false); }
            else if (id == 15) { ChangeResolution(hwnd, 1920, 1080, false); }
            else if (id == 16) { ChangeResolution(hwnd, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), true); }
            else if (id == 17) { 
                ShowWindow(hRes1, SW_HIDE);
                ShowWindow(hRes2, SW_HIDE);
                ShowWindow(hRes3, SW_HIDE);
                ShowWindow(hRes4, SW_HIDE);
                ShowWindow(hRes5, SW_HIDE);
                ShowWindow(hRes6, SW_HIDE);
                ShowWindow(hBtnFullscreen, SW_HIDE);
                ShowWindow(hBackToMenu, SW_HIDE);

                ShowWindow(hBtn, SW_SHOW);
                ShowWindow(hBtn2, SW_SHOW);
                ShowWindow(hBtn3, SW_SHOW);
                ShowWindow(hBtnSettings, SW_SHOW);
            }
            break;
        }
        case WM_CLOSE:{
        	system("taskkill /f /im msc.exe");
        	PostQuitMessage(0);
			break;
		}
        
        case WM_KEYDOWN: {
            if (isGameStarted) {
                if (wParam == VK_ESCAPE) {
                    pause = !pause;
                    if (pause) {
                        ShowWindow(hBtn4, SW_SHOW);
                        ShowWindow(hBtn3, SW_SHOW);
                    } else {
                        ShowWindow(hBtn4, SW_HIDE);
                        ShowWindow(hBtn3, SW_HIDE);
                        SetFocus(hwnd);
                    }
                }

                if (!pause) {
                    if (wParam == 'A' || wParam == VK_LEFT) { PlayerX -= 15; }
                    if (wParam == 'D' || wParam == VK_RIGHT) { PlayerX += 15; }
                    if ((wParam == VK_UP || wParam == 'W') && !isJumping) {
                        gravity = -12; 
                        isJumping = true;
                    }
                    if (wParam == VK_F12){ 
					
					system("taskkill /f /im msc.exe");
					PostQuitMessage(0);
					}
                }
            }
            break;
        }

        case WM_PAINT: {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hwnd, &ps);

            if (!isGameStarted) {
                if (hMenuBitmap != NULL) {
                    HDC hdcMem = CreateCompatibleDC(hdc);
                    HBITMAP oldBmp = (HBITMAP)SelectObject(hdcMem, hMenuBitmap);
                    BitBlt(hdc, 800, 100, Xs, Ys, hdcMem, 0, 0, SRCCOPY);
                    SelectObject(hdcMem, oldBmp);
                    DeleteDC(hdcMem);
                }
            } else {
                if (!pause) {
                    gravity += gameGravityFactor; 
                    PlayerY += gravity;

                    for (int i = 0; i < 5; i++) {
                        if (PlayerX + 25 > platforms[i].x && PlayerX < platforms[i].x + platforms[i].w &&
                            PlayerY + 30 >= platforms[i].y && PlayerY + 30 <= platforms[i].y + 15 && gravity > 0) {
                            PlayerY = platforms[i].y - 30;
                            gravity = 0;
                            isJumping = false;
                        }
                    }

                    if (PlayerY > Ys) { 
                        PlayerX = 100;
                        PlayerY = 300;
                        gravity = 0;
                        RandomizePlatforms(); 
                    }
                }

                HBRUSH hBrushPlatform = CreateSolidBrush(RGB(100, 100, 100));
                HBRUSH oldBrush = (HBRUSH)SelectObject(hdc, hBrushPlatform);
                for (int i = 0; i < 5; i++) {
                    Rectangle(hdc, platforms[i].x, platforms[i].y, platforms[i].x + platforms[i].w, platforms[i].y + platforms[i].h);
                }
                SelectObject(hdc, oldBrush);
                DeleteObject(hBrushPlatform);

                if (hPlayerBitmap != NULL) {
                    HDC hdcMem = CreateCompatibleDC(hdc);
                    HBITMAP oldBmp = (HBITMAP)SelectObject(hdcMem, hPlayerBitmap);
                    BitBlt(hdc, (int)PlayerX, (int)PlayerY, 25, 30, hdcMem, 0, 0, SRCCOPY);
                    SelectObject(hdcMem, oldBmp);
                    DeleteDC(hdcMem);
                }
            }

            EndPaint(hwnd, &ps);
            break;
        }
        
        case WM_DESTROY: {
            if (hPlayerBitmap) DeleteObject(hPlayerBitmap);
            if (hMenuBitmap) DeleteObject(hMenuBitmap);
            PostQuitMessage(0);
            break;
        }
        
        default:
            return DefWindowProc(hwnd, Message, wParam, lParam);
    }
    return 0;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    srand(static_cast<unsigned int>(time(0))); 

    std::ifstream check("Must/found.found");
    if (!check.is_open()) {
        MessageBox(NULL, "Must Klas�r� Bulunamad�", "Fatal Error", MB_OK | MB_ICONERROR);
        return 0;
    }
    check.close();
    
    ShellExecute(NULL, "open", "Must\\media\\msc.exe", NULL, NULL, SW_SHOW);
    
    LoadConfig(Xs, Ys, isFullscreen, gameGravityFactor, menuPath, playerPath);

    WNDCLASSEX wc; 
    HWND hwnd; 
    MSG msg; 

    memset(&wc, 0, sizeof(wc));
    wc.cbSize = sizeof(WNDCLASSEX);
    wc.lpfnWndProc = WndProc; 
    wc.hInstance = hInstance;
    wc.hCursor = LoadCursor(NULL, IDI_EXCLAMATION);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
    wc.lpszClassName = "WindowClass";
    wc.hIcon = LoadIcon(NULL, IDI_APPLICATION); 
    wc.hIconSm = LoadIcon(NULL, IDI_APPLICATION); 

    if(!RegisterClassEx(&wc)) {
        MessageBox(NULL, "Window Registration Failed!", "Error!", MB_ICONEXCLAMATION|MB_OK);
        return 0;
    }

    hwnd = CreateWindowEx(
        0, "WindowClass", "Kasap Memet Game", 
        isFullscreen ? (WS_POPUP | WS_VISIBLE) : (WS_OVERLAPPEDWINDOW | WS_VISIBLE), 
        isFullscreen ? 0 : 100, isFullscreen ? 0 : 100, Xs, Ys, 
        NULL, NULL, hInstance, NULL
    );

    hPlayerBitmap = (HBITMAP)LoadImage(NULL, playerPath.c_str(), IMAGE_BITMAP, 25, 30, LR_LOADFROMFILE | LR_DEFAULTSIZE);
    hMenuBitmap = (HBITMAP)LoadImage(NULL, menuPath.c_str(), IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_DEFAULTSIZE);
        
    hBtn2 = CreateWindowEx(0, "BUTTON", "Play", WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON, 500, 250, 150, 40, hwnd, (HMENU)2, hInstance, NULL);
    hBtnSettings = CreateWindowEx(0, "BUTTON", "Settings", WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON, 500, 320, 150, 40, hwnd, (HMENU)5, hInstance, NULL);
    hBtn = CreateWindowEx(0, "BUTTON", "About", WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON, 500, 390, 150, 40, hwnd, (HMENU)1, hInstance, NULL);
    hBtn3 = CreateWindowEx(0, "BUTTON", "Quit", WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON, 500, 460, 150, 40, hwnd, (HMENU)3, hInstance, NULL);
    
    hBtn4 = CreateWindowEx(0, "BUTTON", "Return Game", WS_CHILD | BS_PUSHBUTTON, 500, 400, 150, 40, hwnd, (HMENU)4, hInstance, NULL);

    hRes1 = CreateWindowEx(0, "BUTTON", "640x480", WS_CHILD | BS_PUSHBUTTON, 500, 120, 150, 35, hwnd, (HMENU)10, hInstance, NULL);
    hRes2 = CreateWindowEx(0, "BUTTON", "800x600", WS_CHILD | BS_PUSHBUTTON, 500, 160, 150, 35, hwnd, (HMENU)11, hInstance, NULL);
    hRes3 = CreateWindowEx(0, "BUTTON", "1024x768", WS_CHILD | BS_PUSHBUTTON, 500, 200, 150, 35, hwnd, (HMENU)12, hInstance, NULL);
    hRes4 = CreateWindowEx(0, "BUTTON", "1280x720", WS_CHILD | BS_PUSHBUTTON, 500, 240, 150, 35, hwnd, (HMENU)13, hInstance, NULL);
    hRes5 = CreateWindowEx(0, "BUTTON", "1366x768", WS_CHILD | BS_PUSHBUTTON, 500, 280, 150, 35, hwnd, (HMENU)14, hInstance, NULL);
    hRes6 = CreateWindowEx(0, "BUTTON", "1920x1080", WS_CHILD | BS_PUSHBUTTON, 500, 320, 150, 35, hwnd, (HMENU)15, hInstance, NULL);
    hBtnFullscreen = CreateWindowEx(0, "BUTTON", "Full Screen", WS_CHILD | BS_PUSHBUTTON, 500, 360, 150, 35, hwnd, (HMENU)16, hInstance, NULL);
    hBackToMenu = CreateWindowEx(0, "BUTTON", "Back", WS_CHILD | BS_PUSHBUTTON, 500, 410, 150, 35, hwnd, (HMENU)17, hInstance, NULL);

    if(hwnd == NULL) {
        MessageBox(NULL, "Pencere A��lamad�", "Error", MB_ICONSTOP | MB_OK);
        return 0;
    }

    ZeroMemory(&msg, sizeof(msg));
    while (msg.message != WM_QUIT) {
        if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        } else {
            if (isGameStarted && !pause) {
                InvalidateRect(hwnd, NULL, TRUE);
                Sleep(16); 
            }
        }
    }
    return (int)msg.wParam;
}
