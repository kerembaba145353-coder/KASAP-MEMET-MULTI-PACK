==================================================
KASAP MEMET GAME - README
==================================================

This project is a simple 2D platformer game developed from 
scratch using ISO C++98 and the Windows API (Win32API).

FEATURES:
- Win32 API: Written using pure ISO C++98 and the Windows API without any external game engines.
- Dynamic Resolution and Fullscreen Support: Multiple resolution options (ranging from 640x480 up to 1920x1080) and fullscreen mode.
- Configuration File: Game settings (config.ini) are automatically saved and loaded.
- Dynamic Platforms: Platforms are randomized every time the game starts.
- The F12 key forcefully closes the game without showing any warning.

REQUIREMENTS:
- Windows Operating System
- A "Must" folder in the working directory containing the required "bmp" model files and the "found.found" control file.

====================================================
KASAP MEMET GAME - Developer Information
====================================================

- Win32API was used for this project, and the source codes are located inside the SourceCodes folder.
- You can customize this project via the config.ini file, or even modify the code and rebuild the game from scratch.
- All images of the game are stored in a folder named models.
- This game consists entirely of royalty-free music and images.
- Sounds are stored in the media folder.
- This project features a background music player created by KASAPMEMET, which plays music in the background (Must\media\msc.exe).

- Creator : KASAPMEMET
- Youtube channel link : https://www.youtube.com/@KASAP_MEMET
- Date : 04.08.2026
- Time : 17.14
- Note : Please Subscribe my youtube channel !
- Note 2 : Im Stupid !