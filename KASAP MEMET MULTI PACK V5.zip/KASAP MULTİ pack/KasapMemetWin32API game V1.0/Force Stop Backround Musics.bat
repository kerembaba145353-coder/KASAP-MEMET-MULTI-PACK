@echo off

taskkill /f /im msc.exe