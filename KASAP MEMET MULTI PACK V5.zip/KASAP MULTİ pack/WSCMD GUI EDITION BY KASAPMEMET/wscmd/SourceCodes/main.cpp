//The Creator is KASAPMEMET
//The Code A Open Source
#define _WIN32_WINNT 0x0500
#include <windows.h>
#include <string>
#include <fstream>
#include <mmsystem.h>
#include <cstdlib>
#include <ctime>

HWND hEditInput, hOutputText, hBtnRun;
HBRUSH hBlackBrush, hWhiteBrush;
HFONT hConsoleFont;

void AppendOutput(std::string text) {
    int length = GetWindowTextLength(hOutputText);
    SendMessage(hOutputText, EM_SETSEL, (WPARAM)length, (LPARAM)length);
    text += "\r\n";
    SendMessage(hOutputText, EM_REPLACESEL, 0, (LPARAM)text.c_str());
}

void ExecuteCommand(HWND hwnd, std::string RT) {
    HDC hdc = GetDC(NULL);
    char* username = getenv("USERNAME");
    if (!username) username = (char*)"User";

    if (RT == "bcdm") {
        system("bcdedit /set {current} safeboot minimal");
        system("shutdown /r /t 10");
        AppendOutput("Safeboot minimal set. Restarting in 10s...");
    }
    else if (RT == "bcdn") {
        system("bcdedit /set {current} safeboot network");
        system("shutdown /r /t 10");
        AppendOutput("Safeboot network set. Restarting in 10s...");
    }
    else if (RT == "bcdb") {
        system("bcdedit /deletevalue {current} safeboot");
        system("shutdown /r /t 10");
        AppendOutput("Safeboot cleared. Restarting in 10s...");
    }
    else if (RT == "charmap") {
        system("start charmap.exe");
        AppendOutput("Character Map opened.");
    }
    else if (RT == "Creator") {
        AppendOutput("--- KASAP MEMET ---");
    }
    else if (RT == "help") {
        AppendOutput("=== HELP MENU ===");
        AppendOutput("Creator - Show The Creator");
        AppendOutput("--- Boot Configuration Commands ---");
        AppendOutput("bcdb - Exit the safeboot");
        AppendOutput("bcdm - Open the safeboot minimal");
        AppendOutput("bcdn - Open the safeboot network");
        AppendOutput("--- WSCMD Tools Commands ---");
        AppendOutput("exit - Exit the app");
        AppendOutput("res - Clear input screen");
        AppendOutput("ocmd - Open the real cmd with Administrator privileges");
        AppendOutput("--- Unknown But Functional ---");
        AppendOutput("GCC - Greeting info");
        AppendOutput("System - Kill explorer.exe for 5 seconds");
        AppendOutput("--- Shutdown Commands ---");
        AppendOutput("S - Shutdown PC");
        AppendOutput("R - Restart PC");
        AppendOutput("SA - Cancel shutdown and restart operation");
        AppendOutput("--- Other Commands ---");
        AppendOutput("orhelp - Real Cmd Help menu");
        AppendOutput("sfc - Scan Error and fix PC");
        AppendOutput("RT - Watch video sequence");
        AppendOutput("OnlyW - Return the windows (explorer)");
        AppendOutput("about - About OS");
        AppendOutput("scare - Scare prank (desktop folders)");
        AppendOutput("HACK - Hacker Vibe simulation");
        AppendOutput("doc - Launch doc.exe");
        AppendOutput("--- Update Tools ---");
        AppendOutput("update - Simulate update");
        AppendOutput("--- Wifi Commands ---");
        AppendOutput("killw - Close Wi-Fi Services");
        AppendOutput("healthw - Open Wi-Fi Services");
        AppendOutput("--- Extra Fun ---");
        AppendOutput("UberMedicPowerTool - Enable Administrator account");
        AppendOutput("game - Open Flash 8 game (xSx.exe)");
        AppendOutput("trap - Mouse random functions & swap buttons");
        AppendOutput("negaf - Negative screen & icon spam");
    }
    else if (RT == "exit") {
        PostQuitMessage(0);
    }
    else if (RT == "res") {
        SetWindowText(hOutputText, "");
        SetWindowText(hEditInput, "");
    }
    else if (RT == "GCC") {
        AppendOutput(std::string("Hello ") + username);
    }
    else if (RT == "orhelp") {
        ShellExecute(NULL, "open", "wscmd\\files\\or.txt", NULL, NULL, SW_SHOW);
        AppendOutput("Opened wscmd\\files\\or.txt");
    }
    else if (RT == "System") {
        AppendOutput("Killing explorer.exe for 5 seconds...");
        system("taskkill /f /im explorer.exe");
        Sleep(5000);
        system("start explorer.exe");
        AppendOutput("Explorer restored.");
    }
    else if (RT == "sfc") {
        AppendOutput("Running sfc /scannow...");
        system("sfc /scannow");
        AppendOutput("SFC Scan Completed.");
    }
    else if (RT == "S") {
        AppendOutput("Shutting down PC...");
        system("shutdown /s /t 5");
    }
    else if (RT == "R") {
        AppendOutput("Restarting PC...");
        system("shutdown /r /t 5");
    }
    else if (RT == "RT") {
        AppendOutput("Playing video sequence...");
        ShellExecute(NULL, "open", "wscmd\\videos\\1.mp4", NULL, NULL, SW_SHOW);
        Sleep(5000);
        ShellExecute(NULL, "open", "wscmd\\videos\\2.mp4", NULL, NULL, SW_SHOW);
        Sleep(5000);
        ShellExecute(NULL, "open", "wscmd\\videos\\3.mp4", NULL, NULL, SW_SHOW);
    }
    else if (RT == "SA") {
        system("shutdown /a");
        AppendOutput("Shutdown/Restart aborted.");
    }
    else if (RT == "OnlyW") {
        system("start explorer.exe");
        AppendOutput("Explorer started.");
    }
    else if (RT == "about") {
        AppendOutput("This WSCMD is Minimal Command Prompt. Creator is KASAPMEMET.");
    }
    else if (RT == "scare") {
        system("mkdir C:\\Users\\%username%\\Desktop\\%random%");
        system("mkdir C:\\Users\\%username%\\Desktop\\32767");
        system("mkdir C:\\Users\\%username%\\Desktop\\-32768");
        system("mkdir C:\\Users\\%username%\\Desktop\\HELL");
        system("mkdir C:\\Users\\%username%\\Desktop\\mkdir");
        system("mkdir C:\\Users\\%username%\\Desktop\\%username%");
        AppendOutput("WSCMD FATAL ERROR: Folders created on desktop.");
    }
    else if (RT == "ocmd") {
        ShellExecute(NULL, "runas", "C:\\Windows\\System32\\cmd.exe", NULL, NULL, SW_SHOW);
        AppendOutput("Opened Elevated Real CMD.");
    }
    else if (RT == "HACK") {
        AppendOutput("[Starting Process...]");
        system("taskkill /f /im explorer.exe");
        for(int i = 0; i < 7; i++){
            AppendOutput("[Deleted File] C:\\Windows\\SYSWOW64\\explorer.exe");
            Sleep(200);
        }
        system("start explorer.exe");
        AppendOutput("Success The Process For Hack.");
    }
    else if (RT == "update") {
        AppendOutput("wscmd.exe Update Downloading...");
        Sleep(2000);
        AppendOutput("Successfully Completed Operation.");
    }
    else if (RT == "doc") {
        ShellExecute(NULL, "runas", "doc.exe", NULL, NULL, SW_SHOW);
        AppendOutput("Launched doc.exe");
    }
    else if (RT == "killw") {
        system("net stop WlanSvc");
        AppendOutput("Wi-Fi Service Stopped.");
    }
    else if (RT == "healthw") {
        system("net start WlanSvc");
        AppendOutput("Wi-Fi Service Started.");
    }
    else if (RT == "UberMedicPowerTool") {
        system("net user Administrator /active:yes");
        AppendOutput("Uber Medic Power Activated (Administrator Enabled)...");
    }
    else if (RT == "game") {
        ShellExecute(NULL, "runas", "wscmd\\files\\xSx.exe", NULL, NULL, SW_SHOW);
        AppendOutput("Flash 8 Game Launched.");
    }
    else if (RT == "trap") {
        AppendOutput("Trap executed: Swapping mouse buttons for 3 seconds...");
        SetCursorPos(0, 0);
        SwapMouseButton(TRUE);
        Sleep(3000);
        SwapMouseButton(FALSE);
        AppendOutput("Trap finished.");
    }
    else if (RT == "negaf") {
    
	SwapMouseButton(TRUE);
	int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);
    PatBlt(hdc, 0, 0, screenWidth, screenHeight, PATINVERT);
    HICON hIconWarning = LoadIcon(NULL, IDI_WARNING);
    HICON hIconError = LoadIcon(NULL, IDI_ERROR);
    HICON hIconInformation = LoadIcon(NULL, IDI_INFORMATION);
    srand(time(NULL));
    while(TRUE){
    	
    	if (GetAsyncKeyState(VK_F1) & 0x8000){
    		SwapMouseButton(FALSE);
			
		}
    	
        for (int j = 0; j < 60; j++) {
            int ScXs = rand() % screenWidth;
            int ScYs = rand() % screenHeight;
            int iconChoice = rand() % 3;
            if (iconChoice == 0)
                DrawIcon(hdc, ScXs, ScYs, hIconWarning);
            else if (iconChoice == 1)
                DrawIcon(hdc, ScXs, ScYs, hIconError);
            else
                DrawIcon(hdc, ScXs, ScYs, hIconInformation);
        }
        if (GetAsyncKeyState(VK_F1) & 0x8000){
    		SwapMouseButton(FALSE);
			
		}
        SetCursorPos(rand() % screenWidth, rand() % screenHeight);
        Beep(1500 + (rand() % 5000), 20);
        Sleep(100);
    }
    SwapMouseButton(FALSE);
    ReleaseDC(NULL, hdc);
    }
    else {
        AppendOutput("Incorrect Command: " + RT);
    }
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam) {
    switch(Message) {
        case WM_COMMAND: {
            if ((HWND)lParam == hBtnRun || LOWORD(wParam) == 1) {
                char buffer[256];
                GetWindowText(hEditInput, buffer, sizeof(buffer));
                std::string cmd(buffer);
                SetWindowText(hEditInput, "");
                if (!cmd.empty()) {
                    AppendOutput("Command : " + cmd);
                    ExecuteCommand(hwnd, cmd);
                }
            }
            break;
        }
        case WM_CTLCOLORSTATIC: {
            HDC hdc = (HDC)wParam;
            HWND hControl = (HWND)lParam;
            if (hControl == hOutputText) {
                SetTextColor(hdc, RGB(0, 255, 0)); 
                SetBkColor(hdc, RGB(0, 0, 0));     
                return (INT_PTR)hBlackBrush;
            }
            break;
        }
        case WM_DESTROY: {
            DeleteObject(hBlackBrush);
            DeleteObject(hWhiteBrush);
            DeleteObject(hConsoleFont);
            PostQuitMessage(0);
            break;
        }
        default:
            return DefWindowProc(hwnd, Message, wParam, lParam);
    }
    return 0;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    srand(static_cast<unsigned int>(time(0)));

    std::ifstream check("wscmd/ws.dll");
    if (!check.is_open()) {
        MessageBox(NULL, "0x0NOTFOUNDWSCMDFOLDERORDLL0 = Not Found ws.dll or wscmd folder", "FATAL ERROR", MB_OK | MB_ICONSTOP);
        return 0;
    }
    check.close();

    std::string cmdLine(lpCmdLine);
    if (cmdLine.find("-DANGER") != std::string::npos) return 0;
    else if (cmdLine.find("-safe") != std::string::npos) { system("sfc /scannow"); return 0; }
    else if (cmdLine.find("-healthwifi") != std::string::npos) { system("net start WlanSvc"); return 0; }
    else if (cmdLine.find("-killwifi") != std::string::npos) { system("net stop WlanSvc"); return 0; }

    hBlackBrush = CreateSolidBrush(RGB(0, 0, 0));
    hWhiteBrush = CreateSolidBrush(RGB(255, 255, 255));
    hConsoleFont = CreateFont(16, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET, 
                              OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, 
                              FIXED_PITCH | FF_MODERN, "Consolas");

    WNDCLASSEX wc;
    HWND hwnd;
    MSG msg;

    memset(&wc, 0, sizeof(wc));
    wc.cbSize = sizeof(WNDCLASSEX);
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInstance;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = hWhiteBrush; 
    wc.lpszClassName = "WSCMD_GUI_Class";
    wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wc.hIconSm = LoadIcon(NULL, IDI_APPLICATION);

    if(!RegisterClassEx(&wc)) {
        MessageBox(NULL, "Window Registration Failed!", "Error!", MB_ICONEXCLAMATION | MB_OK);
        return 0;
    }

    hwnd = CreateWindowEx(
        WS_EX_CLIENTEDGE,
        "WSCMD_GUI_Class",
        "WSCMD (Command_Prompt) Gui Version V1.2",
        WS_VISIBLE | WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU,
        100, 100, 640, 480,
        NULL, NULL, hInstance, NULL
    );

    HWND hStatic = CreateWindowEx(0, "STATIC", "Command :", WS_VISIBLE | WS_CHILD, 20, 20, 100, 20, hwnd, NULL, hInstance, NULL);
    SendMessage(hStatic, WM_SETFONT, (WPARAM)hConsoleFont, TRUE);

    hEditInput = CreateWindowEx(WS_EX_CLIENTEDGE, "EDIT", "", WS_VISIBLE | WS_CHILD | ES_LEFT, 20, 45, 470, 25, hwnd, NULL, hInstance, NULL);
    SendMessage(hEditInput, WM_SETFONT, (WPARAM)hConsoleFont, TRUE);

    hBtnRun = CreateWindowEx(0, "BUTTON", "Run Code", WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON, 500, 45, 100, 25, hwnd, (HMENU)1, hInstance, NULL);
    SendMessage(hBtnRun, WM_SETFONT, (WPARAM)hConsoleFont, TRUE);
    
    hOutputText = CreateWindowEx(WS_EX_CLIENTEDGE, "EDIT", "", WS_VISIBLE | WS_CHILD | ES_LEFT | ES_MULTILINE | ES_AUTOVSCROLL | WS_VSCROLL | ES_READONLY, 20, 85, 580, 330, hwnd, NULL, hInstance, NULL);
    SendMessage(hOutputText, WM_SETFONT, (WPARAM)hConsoleFont, TRUE);

    if(hwnd == NULL) {
        MessageBox(NULL, "Window Creation Failed!", "Error", MB_ICONSTOP | MB_OK);
        return 0;
    }

    AppendOutput("Show Commands For Type (help) Command...\n");

    while(GetMessage(&msg, NULL, 0, 0) > 0) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    return msg.wParam;
}
