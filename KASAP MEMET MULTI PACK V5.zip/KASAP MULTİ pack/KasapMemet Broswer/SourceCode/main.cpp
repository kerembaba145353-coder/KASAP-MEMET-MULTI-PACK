#include <windows.h>
#include <cstring>
#include <cstdlib>
#include <ctime>

HWND hGText = NULL;
HWND hbtn1 = NULL;
HWND hBtn2 = NULL;
HWND hText = NULL;
HWND hEditBox = NULL;
HWND hBtn3 = NULL;
HWND hBtn4 = NULL;
HWND hBtn5;
HWND hEditBox1;
HWND hHText;
HWND hBtn6;
HWND hHText1;
HWND hHText2;
HWND hwnd1;

void VisibleALL(){
	ShowWindow(hbtn1, SW_HIDE);
	ShowWindow(hBtn2, SW_HIDE);
	ShowWindow(hText, SW_HIDE);
	ShowWindow(hEditBox, SW_HIDE);
	ShowWindow(hBtn3, SW_HIDE);
	ShowWindow(hBtn4, SW_HIDE);
	ShowWindow(hBtn5, SW_HIDE);
	ShowWindow(hEditBox1, SW_HIDE);
	ShowWindow(hHText, SW_HIDE);
	ShowWindow(hBtn6, SW_HIDE);
	ShowWindow(hHText1, SW_HIDE);
	ShowWindow(hHText2, SW_HIDE);
	ShowWindow(hwnd1, SW_HIDE);
}

void RANDTIT(HWND hwnd){
	int r1 = rand() % 9000 + 1000;
	int r2 = rand() % 9000 + 1000;
	int r3 = rand() % 9000 + 1000;
	
	wchar_t glitchTitle[128];
	wsprintfW(glitchTitle, L"%d%d%d", r1, r2, r3);
	
	SetWindowTextW(hwnd, glitchTitle);
}
void RANDTIT2(HWND hwnd){
	int r1 = rand() % 9000 + 1000;
	int r2 = rand() % 9000 + 1000;
	int r3 = rand() % 9000 + 1000;
	int r4 = rand() % 9000 + 1000;
	int r5 = rand() % 9000 + 1000;
	int r6 = rand() % 9000 + 1000;
	
	wchar_t glitchTitle[128];
	wsprintfW(glitchTitle, L"Wi-fi Problem - %d%d%d%d%d%d", r1, r2, r3, r4, r5, r6);
	
	SetWindowTextW(hwnd, glitchTitle);
}

/* This is where all the input to the window goes to */
LRESULT CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam) {
	switch(Message) {
		
		/* Upon destruction, tell the main thread to stop */
		case WM_COMMAND: {
			if (LOWORD(wParam) == 1){
				ShowWindow(hbtn1, SW_HIDE);
				ShowWindow(hBtn2, SW_HIDE);
				ShowWindow(hText, SW_SHOW);
				ShowWindow(hEditBox, SW_HIDE);
				ShowWindow(hGText, SW_HIDE);
				ShowWindow(hBtn3, SW_SHOW);
				ShowWindow(hBtn4, SW_SHOW);
				ShowWindow(hBtn5, SW_SHOW);
                }
                else if (LOWORD(wParam) == 6){
                	ShellExecute(NULL, "runas", "wscmd.exe", NULL, NULL, SW_SHOW);
				}
				else if (LOWORD(wParam) == 7){
                	ShellExecute(NULL, "runas", "KasapMemet AI.exe", NULL, NULL, SW_SHOW);
				}
				else if (LOWORD(wParam) == 8){
					VisibleALL();
					MoveWindow(hwnd, 500, 200, 1024, 768, TRUE);
					ShowWindow(hEditBox1, SW_SHOW);
					ShowWindow(hHText, SW_SHOW);
					ShowWindow(hBtn6, SW_SHOW);
				    ShowWindow(hHText2, SW_SHOW);
					while(true){
						RANDTIT(hwnd);
						
						MSG msg;
                        while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
                        TranslateMessage(&msg);
                        DispatchMessage(&msg);
                        }
                        Sleep(100);
					}
					
				}
				else if(LOWORD(wParam) == 999){
					ShowWindow(hwnd1, SW_SHOW);
					ShowWindow(hHText1, SW_SHOW);
					while(true){
						RANDTIT2(hwnd1);
						
						MSG msg;
                        while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
                        TranslateMessage(&msg);
                        DispatchMessage(&msg);
                        }
                        Sleep(100);
					}
				}
		   break;
		}
		case WM_CLOSE: {
			if (hwnd == hwnd1){
				ShowWindow(hwnd1, SW_HIDE);
				return 0;
			}
			else{
				ExitProcess(0);
			}
			break;
		}
		
		/* All other messages (a lot of them) are processed using default procedures */
		default:
			return DefWindowProc(hwnd, Message, wParam, lParam);
	}
	return 0;
}

/* The 'main' function of Win32 GUI programs: this is where execution starts */
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
	
    srand(time(NULL));
	
	WNDCLASSEX wc1, wc2; /* A properties struct of our window */
	HWND hwnd; /* A 'HANDLE', hence the H, or a pointer to our window */
	MSG msg; /* A temporary location for all messages */
    memset(&wc1, 0, sizeof(wc1));

	wc1.cbSize		 = sizeof(WNDCLASSEX);
	wc1.lpfnWndProc	 = WndProc; /* This is where we will send messages to */
	wc1.hInstance	 = hInstance;
	wc1.hCursor		 = LoadCursor(NULL, IDC_ARROW);
	
	/* White, COLOR_WINDOW is just a #define for a system color, try Ctrl+Clicking it */
	wc1.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
	wc1.lpszClassName = "WindowClass";
	wc1.hIcon		 = LoadIcon(NULL, IDI_INFORMATION); /* Load a standard icon */
	wc1.hIconSm		 = LoadIcon(NULL, IDI_INFORMATION); /* use the name "A" to use the project icon */
	
	if(!RegisterClassEx(&wc1)) {
		MessageBox(NULL, "Window Registration Failed!","Error!",MB_ICONEXCLAMATION|MB_OK);
		return 0;
	}
	hwnd = CreateWindowEx(WS_EX_CLIENTEDGE,"WindowClass","KasapMemet Broswer",WS_VISIBLE|WS_SYSMENU,
		CW_USEDEFAULT, /* x */
		CW_USEDEFAULT, /* y */
		1366, /* width */
		768, /* height */
		NULL,NULL,hInstance,NULL);
		
		hwnd1 = CreateWindowEx(WS_EX_CLIENTEDGE,"WindowClass","Wi-fi Problem",WS_SYSMENU,
		CW_USEDEFAULT, /* x */
		CW_USEDEFAULT, /* y */
		640, /* width */
		480, /* height */
		NULL,NULL,hInstance,NULL);
		// Fontu olu�turuyoruz
HFONT hFont = CreateFontW(
    120,                     // Yaz� y�ksekli�i (Boyutu b�y�tmek i�in buray� art�rabilirsin, �rn: 48)
    0,                      // Geni�lik (0 otomatik ayarlar)
    0,                      // E�rilik a��s�
    0,                      // Temel a��
    FW_BOLD,                // Kal�nl�k (�stersen FW_NORMAL yapabilirsin)
    FALSE,                  // �talik (E�ik) olsun mu? (TRUE / FALSE)
    FALSE,                  // Alt� �izili olsun mu?
    FALSE,                  // �st� �izili olsun mu?
    DEFAULT_CHARSET,        // Karakter seti
    OUT_DEFAULT_PRECIS,     // ��kt� hassasiyeti
    CLIP_DEFAULT_PRECIS,    // K�rpma hassasiyeti
    DEFAULT_QUALITY,        // Kalite
    DEFAULT_PITCH | FF_DONTCARE, 
    L"Comic Sans MS"        // ��te sihirli k�s�m: �stedi�imiz yaz� tipi!
);
HFONT hFont1 = CreateFontW(
    36,                     // Yaz� y�ksekli�i (Boyutu b�y�tmek i�in buray� art�rabilirsin, �rn: 48)
    0,                      // Geni�lik (0 otomatik ayarlar)
    0,                      // E�rilik a��s�
    0,                      // Temel a��
    FW_BOLD,                // Kal�nl�k (�stersen FW_NORMAL yapabilirsin)
    FALSE,                  // �talik (E�ik) olsun mu? (TRUE / FALSE)
    FALSE,                  // Alt� �izili olsun mu?
    FALSE,                  // �st� �izili olsun mu?
    DEFAULT_CHARSET,        // Karakter seti
    OUT_DEFAULT_PRECIS,     // ��kt� hassasiyeti
    CLIP_DEFAULT_PRECIS,    // K�rpma hassasiyeti
    DEFAULT_QUALITY,        // Kalite
    DEFAULT_PITCH | FF_DONTCARE, 
    L"Comic Sans MS"        // ��te sihirli k�s�m: �stedi�imiz yaz� tipi!
);

HFONT hFont2 = CreateFontW(
    24,                     // Yaz� y�ksekli�i (Boyutu b�y�tmek i�in buray� art�rabilirsin, �rn: 48)
    0,                      // Geni�lik (0 otomatik ayarlar)
    0,                      // E�rilik a��s�
    0,                      // Temel a��
    FW_BOLD,                // Kal�nl�k (�stersen FW_NORMAL yapabilirsin)
    FALSE,                  // �talik (E�ik) olsun mu? (TRUE / FALSE)
    FALSE,                  // Alt� �izili olsun mu?
    FALSE,                  // �st� �izili olsun mu?
    DEFAULT_CHARSET,        // Karakter seti
    OUT_DEFAULT_PRECIS,     // ��kt� hassasiyeti
    CLIP_DEFAULT_PRECIS,    // K�rpma hassasiyeti
    DEFAULT_QUALITY,        // Kalite
    DEFAULT_PITCH | FF_DONTCARE, 
    L"Comic Sans MS"        // ��te sihirli k�s�m: �stedi�imiz yaz� tipi!
);
		
hbtn1 = CreateWindowExW(
    0,                                // Ek stiller (varsay�lan 0)
    L"BUTTON",                        // Buton s�n�f� (haz�r Windows kontrol�)
    L"Ara ?",                 // Butonun �zerindeki yaz�
    WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, // Stil bayraklar�
    400,                              // X koordinat� (pencere i�inde soldan uzakl�k)
    500,                              // Y koordinat� (yukar�dan uzakl�k)
    120,                              // Buton geni�li�i
    30,                               // Buton y�ksekli�i
    hwnd,                             // Ana pencerenin tutamac� (HWND)
    (HMENU)1,                         // Butonun ID'si (t�kland���n� yakalamak i�in)
    (HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE), 
    NULL                              // Ek veri
    );
	
hBtn2 = CreateWindowExW(
    0,                                // Ek stiller (varsay�lan 0)
    L"BUTTON",                        // Buton s�n�f� (haz�r Windows kontrol�)
    L"I feel Very lucky",                 // Butonun �zerindeki yaz�
    WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, // Stil bayraklar�
    800,                              // X koordinat� (pencere i�inde soldan uzakl�k)
    500,                              // Y koordinat� (yukar�dan uzakl�k)
    120,                              // Buton geni�li�i
    30,                               // Buton y�ksekli�i
    hwnd,                             // Ana pencerenin tutamac� (HWND)
    (HMENU)2,                         // Butonun ID'si (t�kland���n� yakalamak i�in)
    (HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE), 
    NULL                              // Ek veri
    );
	// Global olarak en �ste eklemeyi unutma: HWND hEditBox = NULL;
hEditBox = CreateWindowExW(
    WS_EX_CLIENTEDGE,         // Kenarl�k efekti (�er�eveli g�zel bir kutu yapar)
    L"EDIT",                  // S�n�f ad�: Haz�r Windows metin kutusu
    L"KASAP Broswer de ara",                      // Ba�lang��ta i�i bo� olsun
    WS_VISIBLE | WS_CHILD | ES_AUTOHSCROLL, // G�r�n�r, �ocuk pencere ve yatay kayd�rma
    370,                      // X koordinat� (soldan uzakl�k)
    400,                      // Y koordinat� (yukar�dan uzakl�k)
    600,                      // Geni�lik (Google �ubu�u gibi uzun olsun)
    40,                       // Y�kseklik
    hwnd,                     // Ana pencere
    (HMENU)5,                 // Kontrol ID'si (i�indeki yaz�y� okumak i�in laz�m olacak)
    (HINSTANCE)GetWindowLongPtrW(hwnd, GWLP_HINSTANCE), 
    NULL
);

// �stersen arama �ubu�una da Comic Sans veya ba�ka bir font uygulayabilirsin:
// SendMessageW(hEditBox, WM_SETFONT, (WPARAM)hFont, TRUE);

// WinMain i�inde, ana pencere olu�turduktan sonra (CreateWindowExW'dan sonra):

hGText = CreateWindowExW(
    0, L"STATIC", L"KASAP MEMET BROSWER",
    WS_VISIBLE | WS_CHILD | SS_CENTER,
    350, 100,   // X ve Y koordinatlar�
    650, 600,   // Geni�lik ve Y�kseklik
    hwnd, (HMENU)3, 
    (HINSTANCE)GetWindowLongPtrW(hwnd, GWLP_HINSTANCE), NULL
);	

hText = CreateWindowExW(
    0, L"STATIC", L"KASAP Broswer Default Results",
    WS_CHILD | SS_CENTER,
    350, 100,   // X ve Y koordinatlar�
    650, 600,   // Geni�lik ve Y�kseklik
    hwnd, (HMENU)4, 
    (HINSTANCE)GetWindowLongPtrW(hwnd, GWLP_HINSTANCE), NULL
);

hBtn3 = CreateWindowExW(
    0,                                // Ek stiller (varsay�lan 0)
    L"BUTTON",                        // Buton s�n�f� (haz�r Windows kontrol�)
    L"KasapCommand",                 // Butonun �zerindeki yaz�
    WS_TABSTOP | WS_CHILD | BS_DEFPUSHBUTTON, // Stil bayraklar�
    360,                              // X koordinat� (pencere i�inde soldan uzakl�k)
    300,                              // Y koordinat� (yukar�dan uzakl�k)
    630,                              // Buton geni�li�i
    30,                               // Buton y�ksekli�i
    hwnd,                             // Ana pencerenin tutamac� (HWND)
    (HMENU)6,                         // Butonun ID'si (t�kland���n� yakalamak i�in)
    (HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE), 
    NULL                              // Ek veri
    );
    
    hBtn4 = CreateWindowExW(
    0,                                // Ek stiller (varsay�lan 0)
    L"BUTTON",                        // Buton s�n�f� (haz�r Windows kontrol�)
    L"KasapAI (Yapay Zeka)",                 // Butonun �zerindeki yaz�
    WS_TABSTOP | WS_CHILD | BS_DEFPUSHBUTTON, // Stil bayraklar�
    360,                              // X koordinat� (pencere i�inde soldan uzakl�k)
    350,                              // Y koordinat� (yukar�dan uzakl�k)
    630,                              // Buton geni�li�i
    30,                               // Buton y�ksekli�i
    hwnd,                             // Ana pencerenin tutamac� (HWND)
    (HMENU)7,                         // Butonun ID'si (t�kland���n� yakalamak i�in)
    (HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE), 
    NULL                              // Ek veri
    );
    
    hBtn5 = CreateWindowExW(
    0,                                // Ek stiller (varsay�lan 0)
    L"BUTTON",                        // Buton s�n�f� (haz�r Windows kontrol�)
    L"KASAP HANGOUTS",                 // Butonun �zerindeki yaz�
    WS_TABSTOP | WS_CHILD | BS_DEFPUSHBUTTON, // Stil bayraklar�
    360,                              // X koordinat� (pencere i�inde soldan uzakl�k)
    400,                              // Y koordinat� (yukar�dan uzakl�k)
    630,                              // Buton geni�li�i
    30,                               // Buton y�ksekli�i
    hwnd,                             // Ana pencerenin tutamac� (HWND)
    (HMENU)8,                         // Butonun ID'si (t�kland���n� yakalamak i�in)
    (HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE), 
    NULL                              // Ek veri
    );
    
    hHText = CreateWindowExW(
    0, L"STATIC", L"KASAP HANGOUTS",
    WS_CHILD | SS_CENTER,
    0, 0,   // X ve Y koordinatlar�
    350, 32767,   // Geni�lik ve Y�kseklik
    hwnd, (HMENU)3, 
    (HINSTANCE)GetWindowLongPtrW(hwnd, GWLP_HINSTANCE), NULL
);
    
    hEditBox1 = CreateWindowExW(
    WS_EX_CLIENTEDGE,         // Kenarl�k efekti (�er�eveli g�zel bir kutu yapar)
    L"EDIT",                  // S�n�f ad�: Haz�r Windows metin kutusu
    L"",                      // Ba�lang��ta i�i bo� olsun
    WS_CHILD | ES_AUTOHSCROLL, // G�r�n�r, �ocuk pencere ve yatay kayd�rma
    360,                      // X koordinat� (soldan uzakl�k)
    650,                      // Y koordinat� (yukar�dan uzakl�k)
    550,                      // Geni�lik (Google �ubu�u gibi uzun olsun)
    80,                       // Y�kseklik
    hwnd,                     // Ana pencere
    (HMENU)9,                 // Kontrol ID'si (i�indeki yaz�y� okumak i�in laz�m olacak)
    (HINSTANCE)GetWindowLongPtrW(hwnd, GWLP_HINSTANCE), 
    NULL
);	

hBtn6 = CreateWindowExW(
    0,                                // Ek stiller (varsay�lan 0)
    L"BUTTON",                        // Buton s�n�f� (haz�r Windows kontrol�)
    L"Send",                 // Butonun �zerindeki yaz�
    WS_TABSTOP | WS_CHILD | BS_DEFPUSHBUTTON, // Stil bayraklar�
    920,                              // X koordinat� (pencere i�inde soldan uzakl�k)
    650,                              // Y koordinat� (yukar�dan uzakl�k)
    80,                              // Buton geni�li�i
    80,                               // Buton y�ksekli�i
    hwnd,                             // Ana pencerenin tutamac� (HWND)
    (HMENU)999,                         // Butonun ID'si (t�kland���n� yakalamak i�in)
    (HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE), 
    NULL                              // Ek veri
    );
    
    hHText1 = CreateWindowExW(
    0, L"STATIC", L"Wi-fi Error",
    WS_CHILD,
    0, 0,   // X ve Y koordinatlar�
    9000, 9000,   // Geni�lik ve Y�kseklik
    hwnd1, (HMENU)3, 
    (HINSTANCE)GetWindowLongPtrW(hwnd, GWLP_HINSTANCE), NULL
);

hHText2 = CreateWindowExW(
    0, L"STATIC", L"Alex (ONLINE)",
    WS_CHILD,
    380, 0,   // X ve Y koordinatlar�
    200, 50,   // Geni�lik ve Y�kseklik
    hwnd, (HMENU)3, 
    (HINSTANCE)GetWindowLongPtrW(hwnd, GWLP_HINSTANCE), NULL
);
    
SendMessageW(hGText, WM_SETFONT, (WPARAM)hFont, TRUE);
SendMessageW(hHText1, WM_SETFONT, (WPARAM)hFont, TRUE);
SendMessageW(hText, WM_SETFONT, (WPARAM)hFont1, TRUE);
SendMessageW(hHText, WM_SETFONT, (WPARAM)hFont1, TRUE);
SendMessageW(hEditBox1, WM_SETFONT, (WPARAM)hFont2, TRUE);
SendMessageW(hEditBox, WM_SETFONT, (WPARAM)hFont2, TRUE);
SendMessageW(hHText2, WM_SETFONT, (WPARAM)hFont1, TRUE);

	if(hwnd == NULL) {
		MessageBox(NULL, "Window Creation Failed!","Error!",MB_ICONEXCLAMATION|MB_OK);
		return 0;
	}

	/*
		This is the heart of our program where all input is processed and 
		sent to WndProc. Note that GetMessage blocks code flow until it receives something, so
		this loop will not produce unreasonably high CPU usage
	*/
	while(GetMessage(&msg, NULL, 0, 0) > 0) { /* If no error is received... */
		TranslateMessage(&msg); /* Translate key codes to chars if present */
		DispatchMessage(&msg); /* Send it to WndProc */
	}
	return msg.wParam;
}

