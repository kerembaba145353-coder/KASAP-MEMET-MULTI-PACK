#include <windows.h>

HWND hBtn1 = NULL;
HWND hBtn2 = NULL;
HWND hBtn3 = NULL;
HWND hBtn4 = NULL;
HWND hBtn5 = NULL;
HWND hBtn6 = NULL;
HWND hBtn7 = NULL;
HWND hBtn8 = NULL;
HWND hBtn9 = NULL;

LRESULT CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam) {
	switch(Message) {
		
		case WM_COMMAND: {
             if (LOWORD(wParam) == 1){
             	ExitProcess(0);
			 }
			 else if(LOWORD(wParam) == 2){
			 	system("shutdown /s /t 10");
				MessageBox(hwnd, "Shutdown in 10 Second", "Custom Shutdowner Message", MB_OK | MB_ICONINFORMATION);
			 }
			 else if(LOWORD(wParam) == 3){
			 	system("shutdown /r /t 10");
				MessageBox(hwnd, "Restart in 10 Second", "Custom Shutdowner Message", MB_OK | MB_ICONINFORMATION);
			 }
			 else if(LOWORD(wParam) == 4){
			 	system("bcdedit /set {current} safeboot minimal");
			 	system("shutdown /r /t 10");
			 	MessageBox(hwnd, "Restart in 10 Second", "Custom Shutdowner Message", MB_OK | MB_ICONINFORMATION);
			 }
			 else if(LOWORD(wParam) == 5){
			 	system("bcdedit /set {current} safeboot network");
			 	system("shutdown /r /t 10");
			 	MessageBox(hwnd, "Restart in 10 Second", "Custom Shutdowner Message", MB_OK | MB_ICONINFORMATION);
			 }
			 else if(LOWORD(wParam) == 6){
			 	system("bcdedit /deletevalue {current} safeboot");
			 	system("shutdown /r /t 10");
			 	MessageBox(hwnd, "Break Safe Boot Successfuly Complated but Computer Restart in 10 Second", "Custom Shutdowner Message", MB_OK | MB_ICONINFORMATION);
			 }
			 else if(LOWORD(wParam) == 7){
			 	system("shutdown /r /t 3 /f");
			 	MessageBox(hwnd, "Restart in 3 Second", "Custom Shutdowner Message", MB_OK | MB_ICONINFORMATION);
			 }
			 else if(LOWORD(wParam) == 8){
			 	system("shutdown /s /t 3 /f");
			 	MessageBox(hwnd, "Shutdown in 3 Second", "Custom Shutdowner Message", MB_OK | MB_ICONINFORMATION);
			 }
			 else if(LOWORD(wParam) == 9){
			 	system("shutdown /a");
			 	MessageBox(hwnd, "Successfully Aborted All Shutdown/Restart Process", "Custom Shutdowner Message", MB_OK | MB_ICONINFORMATION);
			 }
			break;
		}
		case WM_CLOSE: {
			return 0;
			break;
		}
		
		default:
			return DefWindowProc(hwnd, Message, wParam, lParam);
	}
	return 0;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
	
	WNDCLASSEX wc;
	HWND hwnd;
	MSG msg;

	memset(&wc,0,sizeof(wc));
	wc.cbSize		 = sizeof(WNDCLASSEX);
	wc.lpfnWndProc	 = WndProc;
	wc.hInstance	 = hInstance;
	wc.hCursor		 = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = CreateSolidBrush(RGB(150, 150, 150));
	wc.lpszClassName = "WindowClass";
	wc.hIcon		 = LoadIcon(NULL, IDI_APPLICATION);
	wc.hIconSm		 = LoadIcon(NULL, IDI_APPLICATION);

	if(!RegisterClassEx(&wc)) {
		MessageBox(NULL, "Window Registration Failed!","Error!",MB_ICONEXCLAMATION|MB_OK);
		return 0;
	}

	hwnd = CreateWindowEx(
    WS_EX_CLIENTEDGE, 
    "WindowClass", 
    "Custom Shutdowner", 
    WS_VISIBLE | WS_CAPTION | WS_POPUP, 
    200, 200, 230, 480, NULL, NULL, hInstance, NULL
);
	hBtn1 = CreateWindowEx(0, "BUTTON", "Close", WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON, 10, 410, 200, 30, hwnd, (HMENU)1, hInstance, NULL);
	hBtn2 = CreateWindowEx(0, "BUTTON", "Normal Shutdown", WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON, 10, 10, 200, 30, hwnd, (HMENU)2, hInstance, NULL);
	hBtn3 = CreateWindowEx(0, "BUTTON", "Normal Restart", WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON, 10, 50, 200, 30, hwnd, (HMENU)3, hInstance, NULL);
	hBtn4 = CreateWindowEx(0, "BUTTON", "Safe Boot minimal", WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON, 10, 90, 200, 30, hwnd, (HMENU)4, hInstance, NULL);
	hBtn5 = CreateWindowEx(0, "BUTTON", "Safe Boot network", WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON, 10, 130, 200, 30, hwnd, (HMENU)5, hInstance, NULL);
	hBtn6 = CreateWindowEx(0, "BUTTON", "Exit Safe Boot", WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON, 10, 250, 200, 30, hwnd, (HMENU)6, hInstance, NULL);
	hBtn7 = CreateWindowEx(0, "BUTTON", "Force Restart", WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON, 10, 210, 200, 30, hwnd, (HMENU)7, hInstance, NULL);
	hBtn8 = CreateWindowEx(0, "BUTTON", "Force Shutdown", WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON, 10, 170, 200, 30, hwnd, (HMENU)8, hInstance, NULL);
	hBtn9 = CreateWindowEx(0, "BUTTON", "Abort All", WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON, 10, 350, 200, 30, hwnd, (HMENU)9, hInstance, NULL);

	if(hwnd == NULL) {
		MessageBox(NULL, "Window Creation Failed!","Error!",MB_ICONEXCLAMATION|MB_OK);
		return 0;
	}

	while(GetMessage(&msg, NULL, 0, 0) > 0) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return msg.wParam;
}
