#include <windows.h>

HWND hBtn1 = NULL;
HWND hBtn2 = NULL;
HWND hEdit1 = NULL;
HWND hStaticText1 = NULL;
HWND hStaticText2 = NULL;
HWND hStaticText3 = NULL;
HWND hBtn3 = NULL;
HWND hAboutText = NULL;

LRESULT CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam) {
	switch(Message) {
		
		case WM_COMMAND: {
			int id = LOWORD(wParam);
			
			if (id == 1){
				MessageBox(NULL, "Why you choose is ?", "???", MB_OK | MB_ICONEXCLAMATION);
				for(int i = 1; i <= 10; i++){
					MoveWindow(hwnd, 700, 200, 1920, 300, TRUE);
					Sleep(100);
					MoveWindow(hwnd, 700, 200, 1024, 768, TRUE);
					Sleep(100);
					MoveWindow(hwnd, 700, 200, 300, 1080, TRUE);
				}
				MoveWindow(hwnd, 100, 100, 640, 480, TRUE);
				ShowWindow(hBtn2, SW_SHOW);
				ShowWindow(hBtn1, SW_HIDE);
			}
			else if (id == 7){
			ShowWindow(hStaticText1, SW_HIDE);
          	ShowWindow(hStaticText2, SW_HIDE);
	        ShowWindow(hStaticText3, SW_HIDE);
	        ShowWindow(hAboutText, SW_SHOW);
         	ShowWindow(hBtn2, SW_HIDE);
         	ShowWindow(hBtn3, SW_SHOW);
         	ShowWindow(hEdit1, SW_HIDE);
			}
			else if (id == 8){
				
			ShowWindow(hStaticText1, SW_HIDE);
          	ShowWindow(hStaticText2, SW_HIDE);
	        ShowWindow(hStaticText3, SW_HIDE);
	        ShowWindow(hAboutText, SW_HIDE);
         	ShowWindow(hBtn2, SW_SHOW);
         	ShowWindow(hBtn3, SW_HIDE);
         	ShowWindow(hEdit1, SW_SHOW);
         	ShowWindow(hBtn1, SW_HIDE);
			}
			
			char buffer[256];
			GetWindowText(hEdit1, buffer, sizeof(buffer));
			
			ShowWindow(hStaticText1, SW_HIDE);
			ShowWindow(hStaticText2, SW_HIDE);
			ShowWindow(hStaticText3, SW_HIDE);

			if (strcmp(buffer, "Merhaba") == 0){
				ShowWindow(hStaticText1, SW_SHOW);
			}
			else if (strcmp(buffer, "Nas�ls�n") == 0){
				ShowWindow(hStaticText2, SW_SHOW);
			}
			else if (strcmp(buffer, "Neden K�t�s�n") == 0){
				ShowWindow(hStaticText3, SW_SHOW);
			}
			break;
		}
		
		default:
			return DefWindowProc(hwnd, Message, wParam, lParam);
	}
	return 0;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
	
	WNDCLASSEX wc;
	HWND hwnd;
	MSG msg;

	memset(&wc,0,sizeof(wc));
	wc.cbSize		 = sizeof(WNDCLASSEX);
	wc.lpfnWndProc	 = WndProc;
	wc.hInstance	 = hInstance;
	wc.hCursor		 = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wc.lpszClassName = "WindowClass";
	wc.hIcon		 = LoadIcon(NULL, IDI_APPLICATION);
	wc.hIconSm		 = LoadIcon(NULL, IDI_APPLICATION);

	if(!RegisterClassEx(&wc)) {
		MessageBox(NULL, "Window Registration Failed!","Error!",MB_ICONEXCLAMATION|MB_OK);
		return 0;
	}

	hwnd = CreateWindowEx(
    WS_EX_CLIENTEDGE, 
    "WindowClass", 
    "KasapMemet AI", 
    WS_VISIBLE | WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU, 
    CW_USEDEFAULT, CW_USEDEFAULT, 640, 480, NULL, NULL, hInstance, NULL
);
		
	hBtn1 = CreateWindowEx(0, "BUTTON", "?", WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON, 400, 10, 150, 40, hwnd, (HMENU)1, hInstance, NULL);
	hEdit1 = CreateWindowEx(WS_EX_CLIENTEDGE, "EDIT", "Please Answer The ai", WS_VISIBLE | WS_CHILD | ES_LEFT, 250, 100, 300, 100, hwnd, (HMENU)2, hInstance, NULL);
	
	hStaticText1 = CreateWindowEx(0, "STATIC", "Merhaba", WS_CHILD | SS_LEFT, 50, 220, 200, 30, hwnd, (HMENU)3, hInstance, NULL);
	hStaticText2 = CreateWindowEx(0, "STATIC", "K�t� !", WS_CHILD | SS_LEFT, 50, 250, 200, 30, hwnd, (HMENU)4, hInstance, NULL);
	hStaticText3 = CreateWindowEx(0, "STATIC", "Bo�ver", WS_CHILD | SS_LEFT, 50, 250, 200, 30, hwnd, (HMENU)5, hInstance, NULL);
	hAboutText = CreateWindowEx(0, "STATIC", "Creator is KASAPMEMET im 7th grade student im 12 years old BUT IM STUPID ! Version V1.1", WS_CHILD | SS_LEFT, 100, 100, 300, 30, hwnd, (HMENU)6, hInstance, NULL);
	hBtn2 = CreateWindowEx(0, "BUTTON", "About", WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON, 400, 10, 150, 40, hwnd, (HMENU)7, hInstance, NULL);
	hBtn3 = CreateWindowEx(0, "BUTTON", "Back", WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON, 100, 200, 150, 40, hwnd, (HMENU)8, hInstance, NULL);

	ShowWindow(hStaticText1, SW_HIDE);
	ShowWindow(hStaticText2, SW_HIDE);
	ShowWindow(hStaticText3, SW_HIDE);
	ShowWindow(hAboutText, SW_HIDE);
	ShowWindow(hBtn2, SW_HIDE);
	ShowWindow(hBtn3, SW_HIDE);

	if(hwnd == NULL) {
		MessageBox(NULL, "Window Creation Failed!","Error!",MB_ICONEXCLAMATION|MB_OK);
		return 0;
	}

	while(GetMessage(&msg, NULL, 0, 0) > 0) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return msg.wParam;
}
