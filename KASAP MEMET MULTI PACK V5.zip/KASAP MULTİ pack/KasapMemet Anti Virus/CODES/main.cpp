#include <windows.h>
#include <cstring>
#include <mmsystem.h>
#include <fstream>

using namespace std;

HWND hGText = NULL;
HWND hbtn1 = NULL;
HWND hBtn2 = NULL;
HWND hText = NULL;
HWND hEditBox = NULL;
HWND hBtn3 = NULL;
HWND hBtn4 = NULL;
HWND hText1 = NULL;
HWND hText2 = NULL;
HWND hText3 = NULL;
HWND hBtn31 = NULL;
HWND hTextMenu = NULL;
HWND NOTEPAD = FindWindow(NULL, "C:\\Windows\\System32\\cmd.exe");

LRESULT CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam) {
	switch(Message) {
		
		case WM_DESTROY: {
			PostQuitMessage(0);
			break;
		}
		
		case WM_COMMAND: {
			if (LOWORD(wParam) == 1){
				ShowWindow(hText, SW_SHOW);
				ShowWindow(hBtn2, SW_SHOW);
				ShowWindow(hText2, SW_SHOW);
				ShowWindow(hText3, SW_SHOW);
				PlaySoundA(TEXT("AntiVirus\\Alert.wav"), NULL, SND_FILENAME | SND_ASYNC);
                }
				else if (LOWORD(wParam) == 2){
					MessageBox(hwnd, "QUARANTINED (Infected_Malware_666.exe) and (cmd.exe) Clean PC", "Scanner Engine", MB_OK | MB_ICONEXCLAMATION);
					ShowWindow(hText2, SW_HIDE);
					ShowWindow(hText3, SW_HIDE);
				}
				else if (LOWORD(wParam) == 6){
					PostQuitMessage(0);
				}
				else if (LOWORD(wParam) == 31){
					MoveWindow(hwnd, 100, 100, 1000, 500, TRUE);
					ShowWindow(hGText, SW_SHOW);
					ShowWindow(hBtn31, SW_HIDE);
					ShowWindow(hText1, SW_SHOW);
					ShowWindow(hBtn3, SW_SHOW);
					ShowWindow(hEditBox, SW_SHOW);
					ShowWindow(hTextMenu, SW_SHOW);
				    PlaySoundA(TEXT("AntiVirus\\Start.wav"), NULL, SND_FILENAME | SND_ASYNC);
				}
		   break;
		}
		case WM_CREATE: {
    HMENU hMenu = GetSystemMenu(hwnd, FALSE);
    if (hMenu != NULL) {
        RemoveMenu(hMenu, SC_CLOSE, MF_BYCOMMAND);
        DrawMenuBar(hwnd);
    }
    break;
}
	case WM_CLOSE: {
    MessageBox(hwnd, "Benim Koydu�um Exit neyine yetmedi benim exit tu�undan kapat", "Uyar�", MB_OK | MB_ICONINFORMATION);
    return FALSE; 
}
		
		default:
			return DefWindowProc(hwnd, Message, wParam, lParam);
	}
	return 0;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
	
	ifstream check("AntiVirus/Start.wav");
	ifstream check2("AntiVirus/Alert.wav");
	
	if (!check){
		MessageBox(NULL, "Not Found files", "Fatal Error", MB_OK | MB_ICONSTOP);
		PostQuitMessage(0);
	}
	if (!check2){
		MessageBox(NULL, "Not Found files", "Fatal Error", MB_OK | MB_ICONSTOP);
		PostQuitMessage(0);
	}
	
	WNDCLASSEX wc;
	HWND hwnd;
	MSG msg;

	memset(&wc,0,sizeof(wc));
	wc.cbSize		 = sizeof(WNDCLASSEX);
	wc.lpfnWndProc	 = WndProc;
	wc.hInstance	 = hInstance;
	wc.hCursor		 = LoadCursor(NULL, IDC_ARROW);
	
	wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
	wc.lpszClassName = "WindowClass";
	wc.hIcon		 = LoadIcon(NULL, IDI_EXCLAMATION);
	wc.hIconSm		 = LoadIcon(NULL, IDI_EXCLAMATION);

	if(!RegisterClassEx(&wc)) {
		MessageBox(NULL, "Window Registration Failed!","Error!",MB_ICONEXCLAMATION|MB_OK);
		return 0;
	}

	hwnd = CreateWindowEx(WS_EX_CLIENTEDGE,"WindowClass","KasapMemet Anti Virus",WS_VISIBLE|WS_SYSMENU,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		10,
		130,
		NULL,NULL,hInstance,NULL);
		
HFONT hFont = CreateFontW(
    36,
    0,
    0,
    0,
    FW_BOLD,
    FALSE,
    FALSE,
    FALSE,
    DEFAULT_CHARSET,
    OUT_DEFAULT_PRECIS,
    CLIP_DEFAULT_PRECIS,
    DEFAULT_QUALITY,
    DEFAULT_PITCH | FF_DONTCARE,
    L"Comic Sans MS"
);
HFONT hFont1 = CreateFontW(
    27,
    0,
    0,
    0,
    FW_BOLD,
    FALSE,
    FALSE,
    FALSE,
    DEFAULT_CHARSET,
    OUT_DEFAULT_PRECIS,
    CLIP_DEFAULT_PRECIS,
    DEFAULT_QUALITY,
    DEFAULT_PITCH | FF_DONTCARE,
    L"Conslas"
);
hTextMenu = CreateWindowExW(
    0, L"STATIC", L"Menu",
    WS_CHILD,
    0, 400,
    560, 300,
    hwnd, (HMENU)40,
    (HINSTANCE)GetWindowLongPtrW(hwnd, GWLP_HINSTANCE), NULL
);
		
hbtn1 = CreateWindowExW(
    0,
    L"BUTTON",
    L"Scan Computer",
    WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,
    250,
    430,
    120,
    30,
    hwnd,
    (HMENU)1,
    (HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE),
    NULL
    );
	
hBtn2 = CreateWindowExW(
    0,
    L"BUTTON",
    L"QUARANTINE !",
    WS_TABSTOP | WS_CHILD | BS_DEFPUSHBUTTON,
    100,
    430,
    120,
    30,
    hwnd,
    (HMENU)2,
    (HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE),
    NULL
    );
    
    hBtn31 = CreateWindowExW(
    0,
    L"BUTTON",
    L"Start Anti Virus",
    WS_VISIBLE | WS_TABSTOP | WS_CHILD | BS_DEFPUSHBUTTON,
    0,
    0,
    100,
    100,
    hwnd,
    (HMENU)31,
    (HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE),
    NULL
    );

hGText = CreateWindowExW(
    0, L"STATIC", L"KasapMemet Anti Virus",
    WS_CHILD | SS_CENTER,
    0, 0,
    300, 36,
    hwnd, (HMENU)3,
    (HINSTANCE)GetWindowLongPtrW(hwnd, GWLP_HINSTANCE), NULL
);	

hText = CreateWindowExW(
    0, L"STATIC", L"Anti Virus Scan Answers",
    WS_CHILD,
    10, 50,
    490, 300,
    hwnd, (HMENU)4,
    (HINSTANCE)GetWindowLongPtrW(hwnd, GWLP_HINSTANCE), NULL
);
hText1 = CreateWindowExW(
    0, L"STATIC", L"Use Helper Service if program bugs",
    WS_CHILD,
    560, 400,
    510, 300,
    hwnd, (HMENU)8,
    (HINSTANCE)GetWindowLongPtrW(hwnd, GWLP_HINSTANCE), NULL
);
hText2 = CreateWindowExW(
    0, L"STATIC", L"[Virus Detected] C:\\Windows\\System32\\cmd.exe",
    WS_CHILD,
    10, 90,
    300, 100,
    hwnd, (HMENU)4,
    (HINSTANCE)GetWindowLongPtrW(hwnd, GWLP_HINSTANCE), NULL
);
hText3 = CreateWindowExW(
    0, L"STATIC", L"[Virus Detected] C:\\Windows\\System32\\Kasap123\\Infected_Malware_666.exe",
    WS_CHILD,
    10, 120,
    395, 100,
    hwnd, (HMENU)4,
    (HINSTANCE)GetWindowLongPtrW(hwnd, GWLP_HINSTANCE), NULL
);

hBtn3 = CreateWindowExW(
    0,
    L"BUTTON",
    L"Exit",
    WS_TABSTOP | WS_CHILD | BS_DEFPUSHBUTTON,
    937,
    415,
    50,
    50,
    hwnd,
    (HMENU)6,
    (HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE),
    NULL
    );
    
    hEditBox = CreateWindowEx(
    WS_EX_CLIENTEDGE,
    TEXT("EDIT"),
    TEXT(""),
    WS_CHILD | ES_AUTOHSCROLL,
    570, 430,
	350, 25,
    hwnd,
    (HMENU)7,
    hInstance,
    NULL
);
    
SendMessageW(hGText, WM_SETFONT, (WPARAM)hFont, TRUE);
SendMessageW(hText, WM_SETFONT, (WPARAM)hFont1, TRUE);

	if(hwnd == NULL) {
		MessageBox(NULL, "Window Creation Failed!","Error!",MB_ICONEXCLAMATION|MB_OK);
		return 0;
	}

	while(GetMessage(&msg, NULL, 0, 0) > 0) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return msg.wParam;
}
